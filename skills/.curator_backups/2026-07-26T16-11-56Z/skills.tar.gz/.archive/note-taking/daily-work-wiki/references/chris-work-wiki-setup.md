# Chris Park Daily Work Wiki Setup

Session date: 2026-06-18

This is a session-specific reference for the class-level `daily-work-wiki` skill.

## Current wiki root

```text
/opt/data/daily-work-log/
```

## Created structure

```text
/opt/data/daily-work-log/
├── SCHEMA.md
├── index.md
├── log.md
├── daily/
│   └── 2026-06-18.md
└── topics/
    └── hermes-automation.md
```

## User intent

Chris Park wanted the daily task/work conversation record to be managed like an LLM wiki so that later Slack or Telegram requests can retrieve prior decisions, summaries, and next actions.

## Cron job updated

Daily wiki update job:

- Job name: `KST daily conversation/work markdown log`
- Job ID at creation time: `8f26501d647b`
- Schedule: `50 14 * * *` UTC, equivalent to KST 23:50
- Delivery: `local`
- Toolsets: `terminal`, `file`, `session_search`

The cron prompt was updated to:

1. Read `/opt/data/daily-work-log/SCHEMA.md`.
2. Read `/opt/data/daily-work-log/index.md`.
3. Check recent `/opt/data/daily-work-log/log.md` entries.
4. Use `session_search` to summarize the day's work-related conversations.
5. Create/update `daily/YYYY-MM-DD.md`.
6. Promote repeated subjects to `topics/` or `entities/`.
7. Update `index.md` and append to `log.md`.

## Exclusions

The wiki should exclude:

- Weather briefing details.
- Simple greetings and encouragement messages.
- Routine AI news alert bodies.
- Raw copied chat transcripts.
- Secrets, tokens, and sensitive identifiers.

## Initial pages

- `daily/2026-06-18.md`: Initial log covering setup of scheduled morning weather, AI news, evening encouragement, and daily wiki maintenance.
- `topics/hermes-automation.md`: Topic page for Hermes automation, cron jobs, Telegram/Slack usage, and daily work wiki management.

## Recall pattern

When Chris asks from Slack or Telegram for prior work context, first inspect:

1. `/opt/data/daily-work-log/SCHEMA.md`
2. `/opt/data/daily-work-log/index.md`
3. Relevant `daily/`, `topics/`, `entities/`, or `queries/` pages

Then answer concisely in Korean unless the user asks otherwise.
