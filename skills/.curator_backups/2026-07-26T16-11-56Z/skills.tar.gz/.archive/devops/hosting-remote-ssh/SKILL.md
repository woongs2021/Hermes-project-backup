---
name: hosting-remote-ssh
description: Help users connect VS Code Remote SSH or terminal SSH to shared hosting providers such as Hostinger by identifying the correct SSH credentials and config.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [ssh, vscode, remote-ssh, hosting, hostinger, hpanel]
---

# Hosting Remote SSH

Use this when the user wants to SSH into a hosted website/server from VS Code Remote SSH, a terminal, or another SSH client, and is confused about which password or username to use.

## Core principle

The password requested by SSH is normally the **server SSH account password**, not the hosting-provider account password.

For Hostinger specifically, distinguish these credentials:

- Hostinger login password: logs into Hostinger/hPanel only.
- SSH password: used by `ssh`, SFTP-over-SSH, and VS Code Remote SSH.
- FTP password: may be separate from SSH.
- WordPress admin password: logs into WordPress only.
- MySQL/database password: used by the app/database connection only.
- Email mailbox password: used for hosted email only.

Do not ask the user to paste passwords. Ask them to share only non-secret fields such as host, port, and username.

## Hostinger workflow

1. Have the user open Hostinger hPanel.
2. Go to `Websites` → select the site → `Manage`.
3. Look for `Advanced` → `SSH Access`.
4. Identify:
   - SSH host or server IP
   - SSH port
   - SSH username
   - SSH password reset/change control
5. If the current SSH password is unknown, tell the user to reset/change it in `SSH Access`; providers often do not reveal existing passwords.
6. Use the newly set SSH password when VS Code Remote SSH prompts.

## VS Code Remote SSH config template

Tell the user to put a host alias in `~/.ssh/config`:

```sshconfig
Host hostinger
  HostName <ssh-host-or-server-ip>
  User <ssh-username>
  Port <ssh-port>
```

Then connect to `hostinger` from VS Code Remote SSH and enter the SSH password when prompted.

## Common pitfalls

- Do not use the Hostinger account login password unless Hostinger explicitly says it is also the SSH password.
- Do not use WordPress, MySQL, FTP, or email mailbox passwords for SSH.
- If `SSH Access` is missing, the hosting plan may not include SSH, SSH may need to be enabled, or the user may be viewing the wrong website in hPanel.
- Some providers require key-based SSH or offer both password and SSH-key modes. Follow the provider's SSH page over generic assumptions.
- If password login repeatedly fails, verify host, port, username, and whether the site has SSH enabled before troubleshooting VS Code.
- When testing SSH from the agent, use non-interactive options such as `BatchMode=yes` only as a reachability/auth-method probe. `Permission denied (publickey,password)` means the server and account reached the authentication step; it does not prove the user's password would fail in their own interactive terminal.
- For VPS/root access, if the user provides an IP and wants VS Code Remote SSH, give the minimal `~/.ssh/config` alias first, then tell them to reset/check the VPS root or SSH password in the hosting panel if authentication fails.

## Response style for this user

Keep the answer practical and short. Lead with “SSH password, not Hostinger login password,” then give the hPanel path and the VS Code config snippet. Avoid long generic SSH explanations unless the user asks.
