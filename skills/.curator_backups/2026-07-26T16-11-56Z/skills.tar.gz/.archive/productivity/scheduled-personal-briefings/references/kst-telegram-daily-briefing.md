# KST Telegram Daily Briefing Setup Pattern

Session-derived pattern for scheduling warm personal routines and concise AI news digests over Telegram.

## Jobs created

- Morning comfort + weather
  - KST: 09:00 daily
  - Cron: `0 0 * * *`
  - Deliver: `origin`
  - Toolsets: `web`, `terminal`
  - Content: warm Korean greeting, encouragement, and weather for Gunpo Geumjeong-dong and Gangnam/Umyeon-dong.

- Daily AI news top 5
  - KST: 09:30 daily
  - Cron: `30 0 * * *`
  - Deliver: `origin`
  - Toolsets: `web`, `terminal`
  - Method: balanced, low-token search and summary.

- Evening encouragement
  - KST: 18:00 daily
  - Cron: `0 9 * * *`
  - Deliver: `origin`
  - Toolsets: `terminal`
  - Content: 2–4 warm Korean sentences with a gentle “a little more strength” tone.

- Daily work/conversation Markdown log
  - KST: 23:50 daily
  - Cron: `50 14 * * *`
  - Deliver: `local`
  - Toolsets: `terminal`, `file`, `session_search`
  - Output path pattern: `/opt/data/daily-work-log/YYYY-MM-DD.md`
  - Exclude: weather, simple greetings, routine scheduled AI news.

## AI news prompt constraints

Use for recurring digests when the user wants balanced news without high token spend:

```text
AI 뉴스 선정 방법론 — 균형형 + 저토큰:
- 최근 24~36시간 안에 나온 AI 관련 뉴스/공식 발표/논문/제품 업데이트를 우선 검색한다.
- 검색은 과도하게 많이 하지 말고, 2~4개 쿼리 내에서 핵심 후보를 찾는다.
- 가능하면 1차 출처(회사 블로그, arXiv, 공식 릴리스, 주요 언론)를 우선한다.
- 단순 루머/중복 기사/홍보성 기사는 제외한다.
- 균형 기준: 모델/제품, 빅테크, 인프라·칩, 정책·규제, 연구·논문 중 한쪽으로 너무 쏠리지 않게 고른다.
- 토큰 절약: 불필요한 배경 설명, 긴 기사 요약, 검색 과정 설명은 생략한다.
- 가장 중요한 5개만 고르고, 각 항목은 제목 / 한줄 요약+중요성 / 출처 링크로 3줄 이내 작성한다.
```

## Recall guidance

If the user later asks from Slack or Telegram to recall logged work, the Markdown files can be searched/read if the same environment/profile can access `/opt/data/daily-work-log/`. These files are not automatically present in model context, so the agent should actively search/read them. An `INDEX.md` improves recall reliability for weekly/monthly summaries.
