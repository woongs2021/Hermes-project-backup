# Hermes data export to GitHub: security-first workflow

Use when exporting a Hermes data directory or profile/runtime data to a GitHub repository.

## Core lesson

Do not copy the whole Hermes home/data directory into a repository. Use an allowlist export directory, then scan staged files before committing. Even private repos should exclude runtime credentials, sessions, logs, databases, and raw channel/user IDs.

## Recommended flow

1. Clone the target repo into a temporary worktree.
2. Create a dedicated branch, e.g. `data-curated-upload`.
3. Add `.gitignore` before copying data.
4. Copy only curated artifacts into a repo-local `data/` folder.
5. Redact machine/user/channel delivery IDs in cron/job JSON before staging.
6. Exclude cron output histories and backups unless explicitly needed and manually reviewed.
7. Run staged-file checks:
   - `git diff --cached --name-only`
   - forbidden path scan for `.env`, `auth.json`, `config.yaml`, `channel_directory.json`, `state.db`, `*.db`, `sessions/`, `logs/`, `cache/`, `image_cache/`, `audio_cache/`, `cron/output`, backups
   - high-confidence secret regex scan over staged text files
8. Commit only after the staged list and secret scan pass.
9. Push only after GitHub credential setup is complete.

## Safer Hermes include/exclude guidance

Generally safe candidates:
- curated static assets
- generated images/HTML/Python render scripts/prompt text that pass scan
- profile `SOUL.md` and `profile.yaml`, if the user accepts persona disclosure
- sanitized `cron/jobs.json`, if destination IDs are redacted

Exclude by default:
- `.env`, `.env.*`
- `auth.json`, `auth.lock`
- `config.yaml`, config backups
- `channel_directory.json`, Slack/Telegram manifests
- `state.db*`, `kanban.db*`, `*.db`, `*.db-wal`, `*.db-shm`
- `sessions/`, `logs/`, `cache/`, `image_cache/`, `audio_cache/`
- `profiles/**/home/`, `profiles/**/bin/`, runtime locks/PIDs/state
- `memories/`
- `cron/output/`, cron backups
- profile `skills/` unless separately reviewed; bundled/reference skills often contain token/API examples that trigger scans and create unnecessary risk

## PAT push helper pattern

If the agent cannot use interactive prompts, create a user-run helper script that reads the GitHub PAT with hidden input and stores it via `git credential approve`, never printing the token:

```bash
#!/usr/bin/env bash
set -euo pipefail
cd /tmp/Hermes-project
printf "GitHub username [woongs2021]: "
read -r USERNAME
USERNAME=${USERNAME:-woongs2021}
printf "GitHub PAT token (input hidden): "
stty -echo
read -r TOKEN
stty echo
printf "\n"
if [ -z "$TOKEN" ]; then
  echo "ERROR: empty token"
  exit 1
fi
printf "protocol=https\nhost=github.com\nusername=%s\npassword=%s\n\n" "$USERNAME" "$TOKEN" | git credential approve
unset TOKEN
git push origin data-curated-upload
```

Tell the user not to paste the token into chat. If they are on a VPS, first verify they are in the same filesystem/session where the repo was prepared, e.g. `ls -la /tmp/Hermes-project`.
