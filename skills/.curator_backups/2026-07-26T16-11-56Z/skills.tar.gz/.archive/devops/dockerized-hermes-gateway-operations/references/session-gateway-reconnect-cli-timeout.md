# Session note: reconnecting Telegram + Slack when `hermes gateway restart` times out

Context: official Docker-style Hermes runtime, active user already `hermes`, existing gateway process running as `/opt/hermes/.venv/bin/hermes gateway run`.

Useful pattern:
1. Before restart, verify there is exactly one real `hermes gateway run` process; ignore the current shell/grep wrapper.
2. Use `hermes gateway restart` only after user approval because it stops/kills running agents.
3. If the restart command times out or returns inconclusive output, immediately verify process state and inspect the real `$HERMES_HOME/logs/gateway.log`.
4. In this observed case, the restart cleanly disconnected Telegram/Slack, started a new gateway, connected both, then received SIGTERM from the timed-out shell; process count became 0 even though the log showed successful connections.
5. Recovery when already running as the non-root `hermes` user: start the gateway as a tracked background process with `source /opt/hermes/.venv/bin/activate && exec hermes gateway run`, not shell-level `&` and not root direct launch.
6. Wait/check readiness, then verify from the real log only after the latest `Starting Hermes Gateway` line:
   - `✓ telegram connected`
   - `✓ slack connected`
   - `Gateway running with 2 platform(s)`
   - no platform errors after that startup marker

Reporting style for this user: concise Korean status only; do not paste long logs or secrets.