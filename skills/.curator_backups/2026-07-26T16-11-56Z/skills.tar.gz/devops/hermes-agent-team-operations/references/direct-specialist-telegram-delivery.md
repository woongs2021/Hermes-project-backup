# Direct specialist Telegram delivery

Use this when Chris wants scheduled/user-facing specialist messages to appear from the specialist's own Telegram DM (Son, Faker, Go Youn-jung, etc.) rather than Karina/default.

## Why this pattern exists

A cron job stored in the default/Karina cron store can run with `profile: son` or `profile: faker` while cron auto-delivery still uses the default/Karina delivery path. The result can look like Karina sent the specialist's message. For Chris's specialist DM loops, this is the wrong UX.

## Required pattern

1. Keep the user-facing specialist job owned by the correct profile in the prompt and metadata.
2. Set cron `deliver` to `local` so cron does not auto-send the final response via Karina/default.
3. In the prompt, require the specialist to send the user-facing DM directly through that profile's Telegram bot token:
   - Son: `/opt/data/profiles/son/.env`
   - Faker: `/opt/data/profiles/faker/.env`
   - Go Youn-jung: `/opt/data/profiles/goyounjung/.env`
4. Use Chris's approved Telegram chat ID only when already part of the user's configured profile setup.
5. Never print or log bot tokens, `.env` contents, raw credentials, or private platform IDs beyond the approved chat ID.
6. If direct send fails, write a local blocker status and do **not** fall back to Karina/default delivery.

## Toolset requirement

If the job will send directly via Telegram Bot API from the prompt, the cron job must include a toolset capable of local HTTP execution, normally `terminal` along with any required `file` / `session_search` toolsets. Without `terminal` or an equivalent HTTP-capable tool, the specialist run may prepare local files but be unable to send the DM.

Recommended `enabled_toolsets` examples:

- Son daily/weekly DM: `["file", "session_search", "terminal"]`
- Faker daily webapp DM: `["file", "session_search", "terminal"]`
- Go Youn-jung generated-image DM: `["terminal", "file", "vision", "web", "session_search"]`

## Prompt block template

```text
<Specialist> Telegram direct-delivery requirement:
- Do NOT rely on cron auto-delivery for the user-facing DM, because default/Karina cron delivery can make the message appear from Karina/default even when the run profile is `<profile>`.
- This cron job's `deliver` target must remain `local` only.
- After preparing the concise user-facing DM and saving required local files, send the DM directly from the `<profile>` Telegram bot using the Telegram Bot API with `TELEGRAM_BOT_TOKEN` from `/opt/data/profiles/<profile>/.env` and Chris's authorized chat ID.
- Start the user-facing DM with `<Specialist>입니다.` so Chris can clearly tell which specialist sent it.
- Use a local Python helper or curl. Never print or log the bot token, raw credentials, private IDs beyond the approved Chris chat ID, or full .env contents.
- If direct Telegram sending fails, write a short local blocker status without exposing credentials; do not fall back to Karina/default delivery.
- The final cron output should be a short local status only, not the full user-facing DM.
```

## Verification

- Check the relevant jobs show `deliver=local`.
- Check the job prompt contains the direct-delivery block.
- Check `enabled_toolsets` includes `terminal` or an equivalent direct-send capability.
- For a user-requested smoke test, trigger the job or send a short direct message from the specialist token and report only success/message IDs, never tokens.
