---
name: creative-artifact-production
description: "Use when creating visual, design, diagram, browser-demo, generative-art, text-art, or interactive creative artifacts; umbrella for HTML/CSS mockups, diagrams, ASCII art/video, p5.js, ComfyUI, TouchDesigner MCP, design systems, Excalidraw, infographics, and real-time visual tools."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [creative, design, diagrams, html, css, ascii, p5js, excalidraw, infographics, prototypes]
    related_skills: [media-content-production]
---

# Creative Artifact Production

## Overview

This is the class-level umbrella for producing creative artifacts rather than prose-only answers. The shared workflow is: clarify the output medium, choose the right artifact lane, generate a concrete file or machine-readable artifact, then verify it visually or structurally before presenting it.

Use this instead of searching for narrow one-off skills such as a particular diagram renderer, web-design style catalog, ASCII utility, or prototype pattern. The details below name the lane-specific tools and pitfalls so one searchable skill covers the whole creative-artifact family.

## When to Use

- The user asks for a diagram, infographic, visual explanation, architecture/cloud graphic, or hand-drawn-style sketch.
- The user asks for HTML/CSS mockups, landing pages, design variants, design-system references, or token/spec files.
- The user asks for ASCII art, text-as-visuals, p5.js/gen-art, browser demos, or interactive prototypes.
- The user asks for TouchDesigner, Excalidraw, p5.js, pretext, or another creative coding environment by name.
- The user asks to humanize or make generated copy sound more natural as part of a creative artifact.

## Core Workflow

1. **Pick the artifact lane first.** Do not mix output formats accidentally: SVG/HTML diagram, Excalidraw JSON, p5.js sketch, static HTML mockup, DESIGN.md, ASCII, or real-time TouchDesigner network.
2. **Create a durable artifact.** Prefer a file path, HTML document, JSON scene, script, or generated media handle over a prose description.
3. **Use references/templates when present.** Many legacy narrow packages had large template banks; treat this umbrella as the routing surface and keep specialized catalogs as archived packages or support files.
4. **Verify.** Run syntax checks for JSON/JS/HTML where practical; use browser or vision review for visual layout claims.
5. **Report the handle and tradeoffs.** Tell the user where the artifact is and which constraints guided the design.

## Lane Guide

### HTML/CSS design artifacts

- For one-off landing pages, dashboards, decks, or prototypes, produce a self-contained HTML file with embedded CSS/JS unless the project requires a framework.
- For throwaway comparison work, generate 2-3 distinct variants rather than over-polishing one direction.
- For real-brand inspiration, use a design-system catalog mindset: extract typography, spacing, color, layout rhythm, and interaction patterns without copying private assets.
- For token/spec work, author DESIGN.md-style sections in canonical order: colors, typography, spacing, components, states, and export notes.

### Diagrams and infographics

- Architecture diagrams: favor dark themed SVG/HTML, clear grouping, labeled flows, and deployment boundaries.
- Infographics: choose layout by information shape (timeline, funnel, matrix, hierarchy, hub-spoke, comparison), then choose style separately.
- Excalidraw: output valid scene JSON, use rough/hand-drawn defaults, and keep element IDs unique.
- Always optimize for readable labels; a beautiful illegible diagram fails the task.

### ASCII and text visuals

- Use local CLI tools when available for banners, boxes, cowsay, and image-to-ASCII conversions.
- For ASCII video or dense text animation, treat it as a media pipeline: inputs, frame composition, palette, encoding, and output verification.
- Keep monospace assumptions explicit and avoid layouts that collapse on mobile chat clients unless the user wants terminal output only.

### Creative coding and interactive demos

- p5.js: use a minimal HTML viewer, deterministic seeds when useful, and export frames when the user needs deliverable media.
- Pretext/text-layout demos: use it when the creative idea is text as geometry, text flowing around obstacles, or DOM-free typographic interaction.
- TouchDesigner MCP: control a running instance by creating operators, wiring networks, setting parameters, and exporting screenshots/video; verify operator state rather than assuming the graph exists.
- ComfyUI or image/video generation pipelines belong here when the task is creative production, but model setup and batch execution details may also overlap with media/ML workflows.

### Voice and copy humanization

- When the artifact includes narrative or product copy, strip generic AI phrasing and add specific voice, stakes, concrete nouns, and rhythm.
- Do not make unsupported biographical claims; humanization changes style, not factual grounding.

## Consolidated Legacy Knowledge

- `architecture-diagram`: dark SVG/HTML architecture and cloud diagrams with strict visual hierarchy.
- `ascii-art`: pyfiglet/cowsay/boxes/toilet/image-to-ASCII utilities and terminal-friendly presentation.
- `ascii-video`: colored ASCII MP4/GIF pipelines with composition, shader, optimization, and troubleshooting references.
- `baoyu-infographic`: 21 layout families x 21 visual styles for structured infographics.
- `claude-design`: context-first one-off HTML artifacts; ask only questions that change the design.
- `design-md`: Google DESIGN.md token/spec authoring and validation.
- `excalidraw`: hand-drawn JSON diagrams with dark-mode/color references and upload script patterns.
- `future-mobile-ux-leadership`: warm product-design coaching and agent-team delegation for future mobile UX work.
- `humanizer`: remove AI-isms and tune prose voice in creative deliverables.
- `p5js`: p5.js sketches, shaders, interaction, 3D, frame export, and local preview.
- `popular-web-designs`: real design-system catalog for style borrowing without copying.
- `pretext`: @chenglou/pretext browser demos and text-as-geometry patterns.
- `sketch`: quick divergent HTML mockups for comparison before implementation.
- `touchdesigner-mcp`: twozero MCP control of TouchDesigner networks, operators, animation, audio-reactive visuals, and export.

## Common Pitfalls

1. **Returning prose instead of an artifact.** Creative tasks usually need a file, JSON, rendered image, or runnable page.
2. **Choosing the renderer too late.** Pick the output medium before writing content; each lane has different constraints.
3. **Flattening package-specific assets.** If an archived narrow skill had support files, do not reference its old relative paths unless those files were explicitly re-homed.
4. **Template cargo culting.** Use templates as starting points, not as a substitute for the user's content and constraints.
5. **No visual verification.** If the artifact is visual, inspect it with browser/vision or run a renderer when possible.

## Verification Checklist

- [ ] Output lane chosen deliberately.
- [ ] Artifact was actually created or transformed.
- [ ] Syntax/rendering checked where practical.
- [ ] Final response includes path/URL plus short design rationale.
- [ ] Any unverified visual assumptions are labeled.
