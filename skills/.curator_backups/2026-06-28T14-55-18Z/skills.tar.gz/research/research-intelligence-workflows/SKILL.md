---
name: research-intelligence-workflows
description: "Use when discovering, monitoring, and organizing external knowledge sources: arXiv papers, RSS/blog feeds, LLM wiki knowledge bases, and Polymarket market data."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [research, arxiv, rss, blogs, knowledge-base, polymarket, monitoring]
    related_skills: []
---

# Research Intelligence Workflows

## Overview

This umbrella covers external research and intelligence gathering: paper discovery, blog/RSS monitoring, local knowledge-base querying, and market-data checks. The shared pattern is source-specific retrieval first, then synthesis with citations/links and clear uncertainty.

## When to Use

- Searching arXiv by keyword, author, category, or ID.
- Monitoring blogs and RSS/Atom feeds for changes.
- Building or querying an interlinked LLM/wiki-style markdown knowledge base.
- Querying Polymarket markets, prices, order books, or historical data.

## arXiv

- Use the arXiv API/script when current paper metadata matters.
- Capture title, authors, date, abstract, arXiv ID, and PDF link.
- For literature review, cluster papers by claim/method rather than listing chronologically.

## Blog and Feed Monitoring

- Use blogwatcher-style RSS/Atom polling for recurring monitoring.
- Store feed URLs and last-seen state outside the summary when running as a cron/watchdog.
- Report only meaningful changes unless the user asked for a full digest.

## Source-led paper briefing loops

When a scheduled paper/research digest is meant to broaden perspective rather than serve an immediate product concept:

- Keep the first pass source-led and domain-led; add product implications only after the evidence summary, and only when useful.
- Encode source preferences directly in the prompt with site-focused queries and accepted fallbacks.
- For mixed academic/Korean-source loops, label source-access uncertainty clearly: full paper read, abstract/metadata only, snippet only, or paywalled.
- Split lanes by research class when useful (for example AI papers vs UX/branding/design-management papers) so each owner can optimize search terms and evaluation criteria.
- Require each daily item to include title, source, one-line core claim, one-line importance, and a link/ID.
- For temporary loops, append compact entries to a Markdown memory file and prune after weekly synthesis rather than accumulating raw daily listings indefinitely.

## LLM Wiki Knowledge Bases

- Use a markdown KB when the task needs durable interlinked notes from a corpus.
- Prefer small, source-linked pages with backlinks over one giant note.
- Query the KB first when the user asks about prior ingested material.

## Polymarket

- Query live markets/prices/order books before reporting odds.
- Include market slug/ID, timestamp, and whether the market is active/resolved.
- Treat market prices as signals, not ground truth forecasts.

## Common Pitfalls

1. **No source links.** Research outputs must include URLs, IDs, or file paths.
2. **Stale market/feed data.** Fetch live data for current claims.
3. **Abstract-only overconfidence.** Label when you have not read the full paper.
4. **Mixing synthesis with evidence.** Separate what sources say from your interpretation.

## Verification Checklist

- [ ] Retrieval tool/API actually ran for current claims.
- [ ] Source IDs/URLs/timestamps included.
- [ ] Synthesis distinguishes evidence from interpretation.
- [ ] Monitoring jobs are quiet when there is no change unless asked otherwise.
