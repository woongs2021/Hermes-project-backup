# Chris weekly paper-report Instagram visuals

Use this reference when Go Youn-jung turns Muyeol's weekly best-3 paper report into Instagram-ready images.

## Trigger

- Runs after the Friday paper loop:
  1. daily Yuna + Go Youn-jung discovery remains 3+3,
  2. Karina compiles the weekly candidate pool,
  3. Muyeol selects and validates the final best 3,
  4. Karina delivers the report,
  5. Go Youn-jung creates a visual-production package from Muyeol's final report.

## Required outputs

Create exactly this package:

1. **Midjourney prompt for carousel slide 1 — title/intro**: dark background with white title text and a short explanatory subtitle.
2. **Midjourney prompt for carousel slide 2 — detail A**: top title + short explanation, with a beautiful mid-page infographic element such as a chart, graph, matrix, map, or structured diagram.
3. **Midjourney prompt for carousel slide 3 — detail B**: top title + short explanation, with a second infographic element such as a comparison table, flow, topology, timeline, or evidence graph.
4. **Midjourney prompt for carousel slide 4 — finish**: closing slide with one distilled takeaway and a calm finish composition.
5. **One generated abstract metaphor wallpaper**: an artful symbolic image derived from the week's theme, separate from the carousel.

All carousel prompts should be **1:1 Instagram-ready** and include `--ar 1:1`. Generate directly only the abstract metaphor wallpaper with Higgsfield when available.

## Source of truth

- Primary: Muyeol's finalized weekly best-3 report injected from Karina's delivery job.
- Supporting: `/opt/data/agent-team-work-log/paper-candidates/weekly-selected-papers.md`.
- Production notes/output folder: `/opt/data/agent-team-work-log/visuals/YYYY-WW/`.

## Carousel prompt direction

Chris's updated preference after testing:

- Do **not** generate the 4 carousel slides directly with Higgsfield; the generated carousel looked too AI-like.
- Instead, produce **4 Midjourney-ready prompts** for the carousel and let Chris use Midjourney / manual typography refinement for higher quality.
- Use `/opt/data/profiles/faker/design-systems/woongdesignv2.md` as the design-system reference and translate it into premium Midjourney prompt language.
- Use 1:1 Instagram square for every slide prompt; include `--ar 1:1`.
- Maintain one coherent carousel system across prompts: same margin rhythm, type scale, tile radius, palette logic, and small-label style.
- Slide structure:
  - Slide 1: dark background with white title text + short explanation. Calm, premium, not loud.
  - Slides 2-3: top area has title + concise explanation; middle area contains a beautiful infographic element such as chart, table, graph, matrix, map, timeline, flow, or structured diagram.
  - Slide 4: finish slide with a distilled takeaway, calm closure, and minimal visual density.
- Overall font scale should be **smaller and more refined** than a poster.
- Make it feel like editorial UI / academic content design, not loud marketing.
- Core quality bar: **AI티가 안 나는 것**. Avoid glossy AI-startup clichés, generic neon/glassmorphism, fake 3D UI, stock-tech symbolism, distorted pseudo-text, uncanny icons, synthetic glow, and over-smooth gradients.
- Korean text should be kept short in the prompts and treated as typography content notes; final Korean typography should be manually checked or added after generation if needed.
- Apply woongdesignv2 principles:
  - warm off-white canvas `#FCFCFF` for content slides, dark ink/charcoal for intro/finish when appropriate, restrained color planes,
  - ink `#010102`, white text on dark intro, Samsung Sharp Sans / Pretendard-like typographic hierarchy,
  - no emoji in artwork, no decorative illustration, no drop shadow,
  - hairline/card/surface logic, 28px rounded tiles,
  - strong whitespace and small labels,
  - tactile print/paper grain and human editorial composition rather than obvious generated-image polish.

## Metaphor wallpaper direction

Chris liked the wallpaper approach but wants it more abstract:

- Do not make the metaphor too literal.
- Avoid obvious objects unless heavily abstracted.
- Let theme emerge through composition, material, rhythm, texture, light, and spatial tension.
- Minimal/no text.
- Suitable as a standalone Instagram post or wallpaper crop.
- Reference broad movements/material sensibilities, not living artists' exact styles:
  - Bauhaus grid discipline,
  - Korean monochrome / Dansaekhwa material restraint,
  - editorial photogram,
  - abstract cartography,
  - constructivist composition,
  - ink-wash atmosphere,
  - material minimalism.

## Higgsfield CLI pattern

```bash
export PATH="/opt/data/.npm-global/bin:$PATH"
higgsfield version
higgsfield workspace status
higgsfield generate create gpt_image_2 \
  --aspect_ratio 1:1 \
  --quality high \
  --resolution 2k \
  --prompt "<prompt>" \
  --wait
```

For specialist-owned cron jobs, check the target profile's Higgsfield state, not only the default shell:

```bash
HOME=/opt/data/profiles/goyounjung/home \
PATH="/opt/data/.npm-global/bin:$PATH" \
higgsfield workspace status
```

If the specialist profile says no workspace/auth while the default profile works, and Chris intends shared Higgsfield usage, copy only the Higgsfield config/credentials files into that profile's home with restrictive permissions (`0600`) and do not print tokens or raw credential JSON.

If wallpaper generation fails because of credits/model/API/workspace issues, do not fake results. Report the blocker and provide the ready-to-run wallpaper prompt. Robustness rule: vision/image-review tools accept raster image formats only (PNG/JPEG/GIF/WEBP). Never pass SVG, JSON, text, empty files, or URL text files into a vision/image input; deliver SVG fallback as a file with caveat or skip vision review for that artifact.

## Production note

Write `/opt/data/agent-team-work-log/visuals/YYYY-WW/README.md` with:

- source report date/week,
- final 3 items,
- woongdesignv2 principles used,
- carousel structure and information architecture,
- chart/diagram choices for slides 2-3,
- finish-slide takeaway,
- four Midjourney prompts for slides 1-4,
- metaphor choice and abstraction strategy,
- Higgsfield wallpaper prompt and output paths/URLs,
- quality notes and limitations.

## Delivery

Final response should include:

- short Korean note,
- four clearly labeled Midjourney prompts for the carousel,
- `MEDIA:/absolute/path` for the generated abstract wallpaper or URL if returned by Higgsfield,
- concise Instagram carousel caption plus wallpaper caption,
- blocker + wallpaper prompt if wallpaper generation failed.
