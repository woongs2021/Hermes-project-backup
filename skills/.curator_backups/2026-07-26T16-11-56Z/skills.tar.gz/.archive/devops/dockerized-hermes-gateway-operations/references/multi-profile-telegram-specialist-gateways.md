# Multi-profile Telegram specialist gateways

Session pattern: the user wanted to meet specialist Hermes profiles (`yuna`, `son`, later `faker`/`muyeol`) as separate Telegram 1:1 chats while keeping `default` as Karina, the orchestrator.

Durable setup pattern:

1. Use one distinct BotFather bot/token per profile. Do not reuse a token across running profile gateways; Telegram polling ownership conflicts.
2. Put each token in that profile's `.env` (official container path: `/opt/data/profiles/<profile>/.env`). Keep permissions at `600`.
3. Add `TELEGRAM_ALLOWED_USERS=<human Telegram user id>` to the same `.env`; this is the human operator's Telegram account id, not the bot id.
4. Validate without leaking secrets:
   - file exists and permissions are `600`
   - `TELEGRAM_BOT_TOKEN` is present and matches `^[0-9]+:[A-Za-z0-9_-]+$`
   - `TELEGRAM_ALLOWED_USERS` includes the user's id
   - print only a tiny redacted prefix like `889…:AAF…`, never the raw token
5. Start the profile gateway as a long-lived tracked background process from the runtime user, e.g.:
   - `cd /opt/hermes && source /opt/hermes/.venv/bin/activate && exec hermes --profile yuna gateway run`
6. Verify:
   - `hermes --profile <profile> gateway status` shows running
   - `/opt/data/profiles/<profile>/logs/gateway.log` has fresh `✓ telegram connected` and `Gateway running with 1 platform(s)` after the latest startup marker
   - existing `default`/Karina gateway remains running and no duplicate gateway for the same profile was started
7. User opens each bot DM in Telegram and sends `/start`, then talks directly to that specialist.

Useful concise status style for this user:

- `<Profile> gateway: 실행 중`
- `Telegram: connected`
- `PID: <pid>`
- `기존 Karina/default gateway도 계속 실행 중`

Avoid raw logs and never print tokens.
