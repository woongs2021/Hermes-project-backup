---
name: daily-work-wiki
description: "Maintain a personal daily work/conversation wiki from Hermes sessions for later recall across Telegram/Slack."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [work-log, wiki, cron, session-search, slack, telegram, markdown]
    category: note-taking
    related_skills: [llm-wiki, obsidian, hermes-agent]
    created_by: agent
---

# Daily Work Wiki

Maintain a compact, interlinked Markdown knowledge base of a user's work-related Hermes conversations so later sessions can answer questions like "what did I decide yesterday?", "summarize this week's next actions", or "what do we know about Hermes automation?" from Telegram, Slack, or CLI.

This skill is a class-level companion to `llm-wiki`: use the LLM wiki architecture, but specialize the ingest/update rules for daily personal work logs and cross-platform recall.

## When This Skill Activates

Use this skill when the user asks to:
- Save daily work conversations, task outcomes, or decisions to Markdown.
- Make conversation history recallable later from Slack/Telegram.
- Manage a personal work wiki, daily log, knowledge base, or Obsidian-like notes from Hermes sessions.
- Schedule a cron job that summarizes daily conversations into a wiki.
- Query prior daily work logs, next actions, decisions, or topic pages.

## Default Architecture

Prefer a single wiki root with this structure:

```text
<WORK_WIKI>/
├── SCHEMA.md
├── index.md
├── log.md
├── daily/
│   └── YYYY-MM-DD.md
├── topics/
├── entities/
├── queries/
└── raw/
```

For Chris Park's current setup, the wiki root is:

```text
/opt/data/daily-work-log/
```

See `references/chris-work-wiki-setup.md` for the session-specific setup details.

## Core Rules

1. **Orient first, every time**
   - Read `SCHEMA.md`.
   - Read `index.md`.
   - Read recent entries from `log.md`.
   - Then query or update pages.

2. **Summarize, do not mirror logs**
   - Use `session_search` to find the day's relevant work conversations.
   - Extract decisions, actions taken, blockers, and next actions.
   - Do not paste long raw chat logs into the wiki.

3. **Separate durable preference from daily records**
   - Stable user preferences belong in memory.
   - Date-bound task progress and daily summaries belong in the wiki.
   - Do not save PR numbers, issue numbers, temporary task progress, or stale artifacts to memory.

4. **Exclude routine noise**
   - Exclude weather briefings, simple greetings, encouragement messages, and routine news alert bodies unless the user explicitly says they are part of the work record.
   - It is fine to note that such items were excluded.

5. **Keep it interlinked**
   - Daily pages should link to relevant `topics/` and `entities/` pages using `[[wikilinks]]`.
   - Repeated subjects should be promoted into concise topic pages.
   - Update `index.md` whenever new daily/topic/entity/query pages are created.
   - Append every wiki maintenance operation to `log.md`.

6. **Protect secrets and privacy**
   - Never write raw API keys, bot tokens, OAuth tokens, credential dumps, phone numbers, or long identifiers.
   - If a detail is useful but sensitive, paraphrase at a high level.

## Per-Agent Team Work Logs

When Hermes is operating as a multi-profile team, keep date-bound specialist learning in per-agent Markdown work logs rather than durable memory.

Recommended pattern:

```text
/opt/data/agent-team-work-log/
├── SCHEMA.md
├── karina/daily/
├── yuna/daily/
├── son/daily/
├── faker/daily/
└── muyeol/daily/
```

Rules:
- Create a daily note only when that agent performed substantive work that day.
- Do not create placeholder/no-work notes for quiet days, simple greetings, `/start`, connection checks, or routine platform tests.
- Summarize outputs, decisions, blockers, next actions, and handoff notes; never mirror raw chat logs.
- Keep the orchestrator's log separate from specialist logs so later recall can distinguish coordination work from research/planning/implementation/validation work.
- Use local-only cron jobs per profile near end-of-day KST when the user wants automatic capture.

## Daily Cron Pattern

For an end-of-day cron, schedule near the user's local end of day and deliver locally only:

- `deliver: local`
- toolsets: `terminal`, `file`, `session_search`
- prompt must be self-contained because cron jobs run in fresh sessions
- include the wiki root path explicitly
- require orientation before writing
- require `index.md` and `log.md` updates

Prompt skeleton:

```text
Every day at <local time>, update the daily work wiki at <WORK_WIKI>.
Do not message the user; save files only.
Orient first: read SCHEMA.md, index.md, and recent log.md.
Use session_search to find today's work-related conversations.
Exclude weather, simple greetings, routine news alert bodies, secrets, and raw logs.
Create/update daily/YYYY-MM-DD.md with summary, decisions, next actions, links, excluded items.
Update relevant topics/entities for repeated subjects.
Update index.md and append to log.md.
```

## Query Pattern

When the user later asks for recall:

1. Orient from `SCHEMA.md` and `index.md`.
2. Identify likely daily/topic/entity/query pages.
3. Read those pages.
4. If needed, search the wiki for keywords.
5. Answer concisely with the source pages referenced, e.g. "based on `daily/2026-06-18.md` and `topics/hermes-automation.md`...".
6. If the answer is a valuable synthesis, optionally file it under `queries/` and update `index.md`/`log.md`.

## Page Templates

### Daily Page

```markdown
---
title: YYYY-MM-DD 업무/대화 로그
created: YYYY-MM-DD
updated: YYYY-MM-DD
type: daily
tags: [work-log]
sources: [session_search]
confidence: medium
---

# YYYY-MM-DD 업무/대화 로그

## 요약
- ...

## 업무 및 결정사항
- ...

## 다음 액션
- ...

## 관련 링크
- [[topic-or-entity]]

## 제외한 항목
- 날씨 브리핑/단순 인사/루틴 뉴스는 기록에서 제외
```

### Topic Page

```markdown
---
title: Topic Title
created: YYYY-MM-DD
updated: YYYY-MM-DD
type: topic
tags: [topic-tag]
sources: [daily/YYYY-MM-DD.md]
confidence: medium
---

# Topic Title

## 개요

## 현재 상태

## 결정사항

## 다음 액션

## 관련 링크
```

## Pitfalls

- **Do not rely on memory alone.** Memory may remember the wiki location, but daily records are files. Read the wiki before answering recall questions.
- **Do not create a flat pile of daily files only.** Promote recurring subjects to `topics/` so Slack/Telegram recall works even when the user does not know the exact date.
- **Do not skip `index.md`.** The index is the fast routing layer for future agents.
- **Do not skip `log.md`.** The log prevents duplicate maintenance and helps future agents see what changed.
- **Do not over-ingest.** A daily work wiki should be compact; long transcripts make it harder to query and easier to leak sensitive data.
- **Use the user's timezone.** Date boundaries must match the user's local day, not server UTC.
