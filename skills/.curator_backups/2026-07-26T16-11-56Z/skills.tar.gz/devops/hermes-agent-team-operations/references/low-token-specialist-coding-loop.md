# Low-token specialist coding loop

Use this pattern when Chris wants a coding project to progress slowly without exhausting a GPT Plus-style token budget, while preserving Karina as orchestrator and Faker as the coding owner.

## Proven operating shape

1. **Plan first, code later.** Save a concise implementation/operating plan under `/opt/data/.hermes/plans/` before scheduling work.
2. **Use one small objective per day.** Each coding run should have a single acceptance criterion and stop after verification. Avoid broad refactors, exploratory feature expansion, or multiple screens/data layers in the same run.
3. **Schedule inside Chris's preferred morning loop window.** Chris currently prefers main work loops to arrive between 09:00 and 10:00 KST. For Faker/webapp planning, use around 09:45 KST unless a specific coding loop needs a different approved slot.
4. **Make profile-owned jobs truly profile-owned.** Create daily coding jobs from Faker's profile cron store, not Karina's default cron store, so the DM appears from Faker and the profile uses the right role/instructions.
5. **Use explicit Telegram target.** For specialist DM delivery, prefer `telegram:<Chris chat id>` over bare `telegram` to avoid home-channel ambiguity in profile-owned cron stores.
6. **Verify the specialist scheduler.** After creating jobs, run `hermes --profile faker cron list` and `hermes --profile faker cron status`. For Muyeol review jobs, also verify `hermes --profile muyeol cron list/status`.
7. **Daily DM report shape.** Faker's final output should be 3-5 short Korean 존댓말 bullets: what changed, verification result, blocker if any, and tomorrow's target.
8. **Friday review timing.** If Friday morning weekly research reports run before the week's coding finishes, schedule a separate Friday evening Muyeol coding addendum rather than trying to merge into the morning report prematurely.
9. **Muyeol addendum shape.** Muyeol should read Faker's daily logs and minimal project files, run a build/check if feasible, then send a concise GO/WATCH/HOLD summary with risks and next-week recommendation.
10. **Log continuity.** Karina should record the plan path, created job IDs or verification handles, and any first-week scope constraints in her daily team work log.

## Example first-week scope

- Monday: project creation and scope lock.
- Tuesday: local install/build/dev readiness check.
- Wednesday: minimal app shell and five placeholder tabs.
- Thursday: lightweight styling and responsive sanity.
- Friday: build verification, Faker weekly handoff, Muyeol evening addendum.

Keep Week 1 to UI skeleton only. Defer real data, Markdown loaders, charts, authentication, deployment, remote DB, and platform integrations until a later approved week.
