---
name: research-intelligence-workflows
description: "Use when discovering, monitoring, and organizing external knowledge sources: arXiv papers, RSS/blog feeds, LLM wiki knowledge bases, and Polymarket market data."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [research, arxiv, rss, blogs, knowledge-base, polymarket, monitoring]
    related_skills: []
---

# Research Intelligence Workflows

## Overview

This umbrella covers external research and intelligence gathering: paper discovery, blog/RSS monitoring, local knowledge-base querying, and market-data checks. The shared pattern is source-specific retrieval first, then synthesis with citations/links and clear uncertainty.

## When to Use

- Searching arXiv by keyword, author, category, or ID.
- Monitoring blogs and RSS/Atom feeds for changes.
- Building or querying an interlinked LLM/wiki-style markdown knowledge base.
- Querying Polymarket markets, prices, order books, or historical data.

## arXiv

- Use the arXiv API/script when current paper metadata matters.
- Capture title, authors, date, abstract, arXiv ID, and PDF link.
- For literature review, cluster papers by claim/method rather than listing chronologically.

## Blog and Feed Monitoring

- Use blogwatcher-style RSS/Atom polling for recurring monitoring.
- Store feed URLs and last-seen state outside the summary when running as a cron/watchdog.
- Report only meaningful changes unless the user asked for a full digest.

## Source-led paper briefing loops

When a scheduled paper/research digest is meant to broaden perspective rather than serve an immediate product concept:

- Keep the first pass source-led and domain-led; add product implications only after the evidence summary, and only when useful.
- Encode source preferences directly in the prompt with site-focused queries and accepted fallbacks.
- For mixed academic/Korean-source loops, label source-access uncertainty clearly: full paper read, abstract/metadata only, snippet only, or paywalled.
- Split lanes by research class when useful (for example AI papers vs UX/branding/design-management papers) so each owner can optimize search terms and evaluation criteria.
- Require each daily item to include title, source, one-line core claim, one-line importance, and a link/ID.
- For temporary loops, append compact entries to a Markdown memory file and prune after weekly synthesis rather than accumulating raw daily listings indefinitely.

### Chris paper-briefing pattern: daily 3+3 with Friday validation

For Chris Park's recurring AI/design paper briefings, avoid long daily digests. Use a capped two-lane structure:

- Yuna lane: exactly 3 AI / AI×design / LLM / agent / human-centered AI papers or research items.
- Go Youn-jung lane: exactly 3 UX / HCI / branding / design-management / design-education papers or research items.
- Keep daily outputs concise and Korean, with title, source/date, link/ID, core claim, Chris-relevance, and source-access confidence.
- Store compact candidate notes during the week so the Friday loop has evidence to rank, not just the latest search results.
- Treat Friday as the validation gate and weekly report with clear ownership: Karina selects the week’s strongest or most Chris-growth-relevant 3+3; Muyeol produces a local validation memo for Karina (links/source-access, overclaims, risks, GO/HOLD/WATCH); Karina synthesizes the final user-facing report and delivers it to Chris via Telegram DM **and** leaves the same summary in Slack.
- Start the Friday weekly report with one front-loaded Korean paragraph explaining **why this 3+3 set was selected as a coherent weekly learning package** before listing the six items. The paragraph should answer “what will Chris see or think more clearly after this week?” rather than “how does this apply to One UI?”
- Prioritize **Chris growth relevance**, not forced One UI linkage: use discovered paper insights and latest trends to stretch Chris beyond the domain he already knows deeply. Focus on what the item teaches him about warm human AI UX, emotional stability, brand/design quality, design education, design leadership, and ontology-designer growth.
- Do not force or add a separate One UI relevance field unless Chris explicitly asks for it. If One UI is mentioned, keep it as optional delayed reflection or downstream synthesis, never the organizing frame.
- Son owns the growth-question/dialogue layer for Chris. For this loop, Son should send **daily** Telegram DM prompts labeled “오늘의 성장 질문” with only 1–2 lightweight questions. Karina frames the question direction from the day’s research, Muyeol reviews for overreach/sensitivity, and Son delivers the final questions. Karina should not take over Son’s reflective coaching role.
- For this user's weekly 3+3 loop, preserve Son/Muyeol guardrails: treat papers as slow/deep thinking tools and trends as faster market/culture signals; distinguish fact, interpretation, Chris question, uncertainty, and risk; track duplicates/repeats as weighting signals without showing duplicate visible bullets; label sensitive topics such as mental health AI, companions, personalization, youth/health, privacy, and emotional dependence.
- Every Friday after the final weekly 3+3 set is selected, append the selected papers/items to `/opt/data/agent-team-work-log/paper-candidates/weekly-selected-papers.md` with source/link/ID, Chris growth relevance, Muyeol status/caution, Korean-source coverage, de-dup notes, and monthly synthesis hooks. Treat this file as the source of truth for monthly 결산; daily candidate files are supporting evidence. Preserve direct paper/source URLs whenever available, not only titles/DOIs/IDs, so future dashboards can open the original source from each card.
- Every four weeks/monthly, produce a Karina synthesis report to Telegram + Slack that summarizes how the month’s research helped Chris grow as an ontology designer: core growth themes, concept/language gained, important paper/trend clusters, Muyeol cautions, Son’s next-month dialogue themes, and what to continue/stop/adjust.
- See `references/chris-3plus3-research-growth-loop.md` for the current Chris-specific ownership model, weekly report shape, monthly report shape, and pitfalls.
- See `references/weekly-selected-papers-dashboard-data-contract.md` for the data contract that keeps weekly selected papers usable for monthly 결산 and future Faker dashboard/log-graph visualizations.
- Include at least one credible Korean paper/research item in each 3-item lane when possible; if no strong Korean candidate exists, state the gap rather than padding with weak sources.
- Do not over-index on arXiv. For daily paper briefings, diversify discovery across arXiv, OpenReview, ACM/CHI/UIST/DIS/CSCW, ACL Anthology, IEEE/Springer/ScienceDirect where accessible, Semantic Scholar/Crossref/Google Scholar-style web results, Korean sources such as RISS/DBpia/KCI/KoreaScience/KCI-listed journals, university labs, and credible design/HCI venues. arXiv may appear, but should not be the default-only source.
- Avoid generic AI-startup hype.

## LLM Wiki Knowledge Bases

- Use a markdown KB when the task needs durable interlinked notes from a corpus.
- Prefer small, source-linked pages with backlinks over one giant note.
- Query the KB first when the user asks about prior ingested material.

## Polymarket

- Query live markets/prices/order books before reporting odds.
- Include market slug/ID, timestamp, and whether the market is active/resolved.
- Treat market prices as signals, not ground truth forecasts.

## Common Pitfalls

1. **No source links.** Research outputs must include URLs, IDs, or file paths.
2. **Stale market/feed data.** Fetch live data for current claims.
3. **Abstract-only overconfidence.** Label when you have not read the full paper.
4. **Mixing synthesis with evidence.** Separate what sources say from your interpretation.

## Verification Checklist

- [ ] Retrieval tool/API actually ran for current claims.
- [ ] Source IDs/URLs/timestamps included.
- [ ] Synthesis distinguishes evidence from interpretation.
- [ ] Monitoring jobs are quiet when there is no change unless asked otherwise.
