---
name: research-intelligence-workflows
description: "Use when discovering, monitoring, organizing, or writing from research sources: arXiv/literature discovery, RSS/blog feeds, LLM wiki knowledge bases, Polymarket data, and publication paper-writing workflows."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [research, arxiv, rss, blogs, knowledge-base, polymarket, monitoring]
    related_skills: []
---

# Research Intelligence Workflows

## Overview

This umbrella covers external research and intelligence gathering: paper discovery, blog/RSS monitoring, local knowledge-base querying, and market-data checks. The shared pattern is source-specific retrieval first, then synthesis with citations/links and clear uncertainty.

## When to Use

- Searching arXiv by keyword, author, category, or ID.
- Monitoring blogs and RSS/Atom feeds for changes.
- Building or querying an interlinked LLM/wiki-style markdown knowledge base.
- Querying Polymarket markets, prices, order books, or historical data.
- Designing experiments, analyzing results, writing LaTeX drafts, preparing reviewer responses, or packaging ML/AI conference submissions.

## arXiv

- Use the arXiv API/script when current paper metadata matters.
- Capture title, authors, date, abstract, arXiv ID, and PDF link.
- For literature review, cluster papers by claim/method rather than listing chronologically.

## Blog and Feed Monitoring

- Use blogwatcher-style RSS/Atom polling for recurring monitoring.
- Store feed URLs and last-seen state outside the summary when running as a cron/watchdog.
- Report only meaningful changes unless the user asked for a full digest.

## AI/AX job-market and education monitoring loops

When Chris asks for recurring research on AI/AX effects on jobs, education, design careers, or business markets, structure it as a source-led multi-lane monitoring loop rather than a generic digest.

- Split evidence by region: Korea and global should be separate sections, with credible source links and source-access caveats.
- Chain ownership instead of asking every agent the same broad question: Yuna establishes AI/AX job-market impact, Go Youn-jung narrows to design-role implications, Son translates job/design shifts into business-market changes, Faker consolidates into tab/log data, and Muyeol validates on Friday.
- Store intermediate reports locally and keep user-facing delivery limited to explicit synthesis/validation unless Chris asks for every intermediate report.
- Capture cross-loop weighting signals: use `paper_loop_weight_ko` for paper-search topics/source classes/evaluation lenses and `obd_loop_weight_ko` for market, job, education, stakeholder, value-exchange, or business-design signals that should influence OBD learning. Use `WATCH` for uncertain but important signals and `LOW` for weak evidence; do not over-steer other loops from one weak article.
- Preserve Korean-readable logging while keeping JSON keys, enum/status values, IDs, paths, URLs, commands, code identifiers, and original source titles unchanged.

## Source-led paper briefing loops

When a scheduled paper/research digest is meant to broaden perspective rather than serve an immediate product concept:

- Keep the first pass source-led and domain-led; add product implications only after the evidence summary, and only when useful.
- Encode source preferences directly in the prompt with site-focused queries and accepted fallbacks.
- For mixed academic/Korean-source loops, label source-access uncertainty clearly: full paper read, abstract/metadata only, snippet only, or paywalled.
- Split lanes by research class when useful (for example AI papers vs UX/branding/design-management papers) so each owner can optimize search terms and evaluation criteria.
- Require each daily item to include title, source, one-line core claim, one-line importance, and a link/ID.
- For temporary loops, append compact entries to a Markdown memory file and prune after weekly synthesis rather than accumulating raw daily listings indefinitely.

### Chris paper-briefing pattern: daily 3+3 with Friday validation

For Chris Park's recurring AI/design paper briefings, avoid long daily digests. Use a capped two-lane structure:

- Yuna lane: exactly 3 AI / AI×design / LLM / agent / human-centered AI papers or research items.
- Go Youn-jung lane: exactly 3 UX / HCI / branding / design-management / design-education papers or research items.
- Keep daily outputs concise and Korean, with title, source/date, link/ID, core claim, Chris-relevance, and source-access confidence.
- Store compact candidate notes during the week so the Friday loop has evidence to rank, not just the latest search results. Daily Yuna/Go Youn-jung candidates should also be appended to `/opt/data/agent-team-work-log/paper-candidates/all-research-items.jsonl` using the local logging contract in `paper-candidates/README.md`, so Faker can later build a searchable dashboard over all daily 3+3 findings, not only the Friday winners.
- Treat Friday as the validation gate and weekly report with clear ownership: keep daily discovery as 3+3 (Yuna 3 + Go Youn-jung 3 each day), Karina compiles a deduplicated weekly candidate pool for comparison, and Muyeol selects/validates the **final best 3 papers/items total** for the user-facing weekly report (links/source-access, overclaims, risks, GO/HOLD/WATCH). Karina delivers Muyeol's finalized **full report** to Chris via Telegram DM **and** leaves the same summary in Slack. Do not make the weekly report 3+3/6-item unless Chris explicitly asks to restore it.
- If Chris wants a lightweight second touchpoint after the full weekly report, keep Karina as the full-report owner and route the user-facing short DM to Son when Son owns PM/growth/SNS-marketer framing. Muyeol should provide local validation input for Son rather than sending the final DM. Son's short weekly DM should be 6–8 lines, Korean `~다` declarative style, emoji at the start of every bullet/sentence line, and clearly secondary to Karina's full report. Include the core theme, why those 3 were selected in one sentence, compact best-3, one validation caution, one OBD/design-leadership implication, one SNS/marketing angle for Instagram/Facebook/LinkedIn/Threads, and a closing line that Karina owns the full report. Append `선정 논문 3개` with Korean translated title + original title + source link for each selected item; never fabricate missing links.
- Start the Friday weekly report with one front-loaded Korean paragraph explaining **why these 3 were selected as the strongest coherent weekly learning package**. The paragraph should answer “what will Chris see or think more clearly after this week?” rather than “how does this apply to One UI?”
- Prioritize **Chris growth relevance**, not forced One UI linkage: use discovered paper insights and latest trends to stretch Chris beyond the domain he already knows deeply. Focus on what the item teaches him about HCI/AI strategy, brand/design quality, design education, design leadership, business/design-management judgment, and ontology-designer growth.
- **Do not over-weight warm human AI UX or emotional stability** in the Chris-relevance explanation. Treat them as secondary lenses that appear only when the paper/research is specifically strong there; avoid making every item sound like it is about “warm AI UX.”
- Do not force or add a separate One UI relevance field unless Chris explicitly asks for it. If One UI is mentioned, keep it as optional delayed reflection or downstream synthesis, never the organizing frame.
- Son owns the growth-question/dialogue layer for Chris. For this loop, Son should send **daily** Telegram DM prompts labeled “오늘의 성장 질문” with only 1–2 lightweight questions. Karina frames the question direction from the day’s research, Muyeol reviews for overreach/sensitivity, and Son delivers the final questions. Karina should not take over Son’s reflective coaching role. When Son also owns the professional marketer lane, add exactly one `SNS 마케팅 팁` line to the daily DM, focused on how Chris could frame/share the day's insight on Instagram, Facebook, LinkedIn, or Threads without overclaiming or sounding like generic AI-startup marketing.
- For this user's weekly best-3 paper loop, preserve Son/Muyeol guardrails: treat papers as slow/deep thinking tools and trends as faster market/culture signals; distinguish fact, interpretation, Chris question, uncertainty, and risk; track duplicates/repeats as weighting signals without showing duplicate visible bullets; label sensitive topics such as mental health AI, companions, personalization, youth/health, privacy, and emotional dependence.
- Every Friday after the final weekly best-3 set is selected, append the selected papers/items to `/opt/data/agent-team-work-log/paper-candidates/weekly-selected-papers.md` with source/link/ID, Chris growth relevance, Muyeol status/caution, Korean-source coverage if relevant, de-dup notes, lane/source signal, and monthly synthesis hooks. Treat this file as the source of truth for monthly 결산; daily candidate files are supporting evidence. Preserve direct paper/source URLs whenever available, not only titles/DOIs/IDs, so future dashboards can open the original source from each card.
- Every Friday after the final weekly best-3 set is selected, Go Youn-jung's visual follow-up should generate **one** 1:1 abstract metaphor image with Higgsfield when available and leave the exact prompt used. Do not produce SNS/Instagram carousel prompt packs, four-slide Midjourney prompt sets, or multiple visual artifacts unless Chris explicitly asks to restore them. Keep the image abstract rather than literal, avoid generic AI-startup aesthetics, treat woongdesignv2 as restraint/material/editorial-quality guidance, and save production notes/outputs under `/opt/data/agent-team-work-log/visuals/YYYY-WW/`. The creative production details live in `creative-artifact-production` → `references/chris-weekly-paper-abstract-visual.md`.
- Every four weeks/monthly, produce a Karina synthesis report to Telegram + Slack that summarizes how the month’s research helped Chris grow as an ontology designer: core growth themes, concept/language gained, important paper/trend clusters, Muyeol cautions, Son’s next-month dialogue themes, and what to continue/stop/adjust.
- See `references/chris-daily-3plus3-weekly-best3-logging.md` for the current Chris-specific daily 3+3 → Friday Muyeol-selected best-3 operating model, JSONL logging contract, cron update checklist, and pitfalls.
- See `references/chris-3plus3-research-growth-loop.md` for historical/current Chris-specific ownership context, weekly/monthly report shape, and pitfalls; prefer the daily 3+3 + Friday best-3 reference when the two differ.
- See `references/weekly-selected-papers-dashboard-data-contract.md` for the data contract that keeps weekly selected papers usable for monthly 결산 and future Faker dashboard/log-graph visualizations.
- Include credible Korean paper/research items when they rank among the best 3 or add important local context; if no strong Korean candidate exists, state the gap rather than padding with weak sources.
- Do not over-index on arXiv. For daily paper briefings, diversify discovery across arXiv, OpenReview, ACM/CHI/UIST/DIS/CSCW, ACL Anthology, IEEE/Springer/ScienceDirect where accessible, Semantic Scholar/Crossref/Google Scholar-style web results, Korean sources such as RISS/DBpia/KCI/KoreaScience/KCI-listed journals, university labs, and credible design/HCI venues. arXiv may appear, but should not be the default-only source.
- Avoid generic AI-startup hype.

## LLM Wiki Knowledge Bases

- Use a markdown KB when the task needs durable interlinked notes from a corpus.
- Prefer small, source-linked pages with backlinks over one giant note.
- Query the KB first when the user asks about prior ingested material.

## Polymarket

- Query live markets/prices/order books before reporting odds.
- Include market slug/ID, timestamp, and whether the market is active/resolved.
- Treat market prices as signals, not ground truth forecasts.

## Research Paper Writing and Submission

Use this lane when the task moves from discovery into producing a publication-ready ML/AI paper. It is still a research workflow: evidence, experiments, citations, analysis, and claims must remain source-backed and reproducible.

- Treat paper writing as an iterative loop, not a linear draft: experiment design → execution/monitoring → statistical analysis → paper structure → review/revision → submission packaging.
- Match the venue early (NeurIPS/ICML/ICLR/ACL/AAAI/COLM) because page limits, anonymization, checklist requirements, BibTeX style, and artifact expectations change the whole workflow.
- Keep claims coupled to evidence: experiment logs, evaluation tables, ablations, human-evaluation protocols, citations, and reviewer-risk notes.
- Use re-homed support files under `references/research-paper-writing/` for writing guides, paper types, checklists, reviewer guidelines, citation workflow, experiment patterns, human evaluation, and methodology notes.
- Use venue starter packages under `templates/research-paper-writing/` when creating LaTeX submissions; preserve style files and bibliographies rather than flattening them.

## Common Pitfalls

1. **No source links.** Research outputs must include URLs, IDs, or file paths.
2. **Stale market/feed data.** Fetch live data for current claims.
3. **Abstract-only overconfidence.** Label when you have not read the full paper.
4. **Mixing synthesis with evidence.** Separate what sources say from your interpretation.

## Verification Checklist

- [ ] Retrieval tool/API actually ran for current claims.
- [ ] Source IDs/URLs/timestamps included.
- [ ] Synthesis distinguishes evidence from interpretation.
- [ ] Monitoring jobs are quiet when there is no change unless asked otherwise.
