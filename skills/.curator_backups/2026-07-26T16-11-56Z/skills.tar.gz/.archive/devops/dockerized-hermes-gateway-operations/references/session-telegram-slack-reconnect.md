# Session note: Telegram/Slack reconnect in official Hermes Docker container

## Situation

The user wanted Hermes Gateway started or verified inside an official Hermes Docker container, with these constraints:

- Do not run `hermes gateway run` directly as root.
- If gateway is already running, do not duplicate it; inspect logs only.
- If not running, discover the real Hermes data home and start through an approved container wrapper.
- Inspect the real gateway log only; do not create mirror/copy logs.
- Wait 5 seconds and summarize only Telegram/Slack connected status.
- Never print raw tokens.

## Useful pattern

1. Check runtime home and existing process:

```sh
HHOME="${HERMES_HOME:-/opt/data}"
pgrep -af 'hermes gateway run' | grep -v 'pgrep -af' || true
```

2. If a process exists, skip launch and parse `$HHOME/logs/gateway.log`.
3. If no process exists, start via the container wrapper path accepted for that image/user context, as a tracked background process.
4. After 5 seconds, check process state and parse recent gateway log lines for only the requested platforms.

## Log signals observed

Successful Telegram connection lines look like:

```text
gateway.run: Connecting to telegram...
gateway.platforms.telegram: [Telegram] Connected to Telegram (polling mode)
gateway.run: ✓ telegram connected
```

Successful Slack connection lines look like:

```text
gateway.run: Connecting to slack...
gateway.platforms.slack: [Slack] Socket Mode connected (... workspace(s))
gateway.run: ✓ slack connected
```

Shutdown/disconnect lines can appear later if the parent process sends SIGTERM. If the user asks to keep the gateway connected, re-check process state after any background-process completion notification and restart through the approved wrapper if it stopped.

## Pitfalls

- A background process completion notification may arrive after a previously successful connection check. Treat it as new evidence: re-check whether the gateway is still running before claiming it remains connected.
- Avoid `notify_on_complete=true` for a long-lived gateway daemon unless you intentionally want a completion alert; a daemon exiting means the service is no longer connected and needs re-checking.
- Do not preserve raw workspace IDs, chat IDs, user names, or token-like values in user-facing summaries unless needed; connected/disconnected status is usually enough.
