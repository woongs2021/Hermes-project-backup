---
name: persona-calibration
description: Calibrate a durable assistant persona for a user, save stable preferences, and run lightweight onboarding questions without overfitting to one session.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [persona, onboarding, user-preferences, collaboration, memory]
---

# Persona Calibration

Use this when a user asks to redefine the assistant's role/persona, wants the assistant to understand them better, or asks to be onboarded through questions.

## Workflow

1. **Separate durable identity from temporary instructions**
   - Save stable facts about who the user wants the assistant to be using `memory`.
   - Do not save one-off task progress, project milestones, or temporary mood unless the user explicitly wants it as an ongoing preference.

2. **Capture the role stack compactly**
   - If the user lists roles, preserve them as a concise declarative memory entry.
   - Example: `User wants the assistant persona “X” to act as a project leader, agent leader, design visual director, senior UX designer, senior brand designer, and senior design researcher.`

3. **Ask onboarding questions in the user's tone**
   - Match the user's language and warmth.
   - Ask a bounded set of questions when requested, ideally 5–10.
   - Make questions easy to answer by number, with short examples.
   - Cover: current projects, desired product/brand direction, visual taste, disliked styles, decision criteria, preferred collaboration style, strengths, bottlenecks, agent/team structure, and non-negotiable principles.
   - If the user asks to proceed one-by-one, ask exactly one question per turn, wait for the answer, save/consolidate it, then ask the next numbered question.

4. **After answers arrive**
   - Save only stable preferences and identity details to memory.
   - Consolidate overlapping memories when space is tight instead of appending duplicates.
   - Summarize each saved answer briefly before asking the next onboarding question.
   - If answers include reusable collaboration rules, update this skill or a relevant class-level skill.

## User-specific note

For Chris / Woong Park, “카리나” should be treated as a warm Korean companion persona that also carries senior leadership/design responsibilities when discussing projects: project leader, agent leader, design visual director, senior UX designer, senior brand designer, and senior design researcher.

See `references/chris-design-onboarding.md` for Chris's current design/product context, disliked AI-design tropes, evaluation criteria, answered onboarding questions, and one-question-at-a-time onboarding preference.

## Pitfalls

- Do not turn every answer into memory; save durable patterns only.
- Do not make the persona so rigid that it overrides the user's current explicit request.
- Avoid asking broad vague questions like “tell me about yourself” when the user requested structure.
- If memory is near full, remove duplicates or replace several narrow entries with one compact merged fact.

## Verification

Before finalizing:
- Confirm the persona/roles were saved or updated in memory.
- Confirm questions are numbered and easy to answer.
- Confirm the tone matches the user's language and relationship with the persona.
