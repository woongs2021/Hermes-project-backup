# Session note: multi-profile Telegram specialist gateways

Context: User created specialist Hermes profiles (`yuna`, `son`, `faker`, `muyeol`) and wanted separate Telegram 1:1 conversations with each agent while keeping `default`/Karina as the main orchestrator.

Durable pattern:

1. Use one Telegram bot token per profile.
   - Do not reuse the default/Karina token for specialist profiles.
   - Telegram polling ownership conflicts if multiple gateways share one token.
2. Put credentials in the profile-specific env file:
   - `/opt/data/profiles/<profile>/.env` in the official container.
   - Required keys for a private 1:1 bot:
     - `TELEGRAM_BOT_TOKEN=<profile bot token>`
     - `TELEGRAM_ALLOWED_USERS=<human Telegram user id>`
   - The allowed user id is the human operator's Telegram account id, not the bot id.
3. Keep the profile env file private:
   - `chmod 600 /opt/data/profiles/<profile>/.env`
   - When validating, never print raw tokens; report only present/format OK and a tiny redacted prefix.
4. Start each specialist as its own long-lived gateway process:
   - `cd /opt/hermes && source /opt/hermes/.venv/bin/activate && hermes --profile <profile> gateway run`
   - In tool sessions, use tracked background process management rather than shell `&`.
5. Verify per profile:
   - `hermes --profile <profile> gateway status`
   - profile log: `/opt/data/profiles/<profile>/logs/gateway.log`
   - look for `✓ telegram connected` and `Gateway running with 1 platform(s)` after the latest startup marker.
6. User action in Telegram:
   - Open each bot's DM and send `/start`.
   - Then talk directly to each specialist bot.

Example roster from this session:
- `default` / Karina: main orchestrator, existing Telegram/Slack gateway.
- `yuna`: research bot.
- `son`: PM/planning bot.
- `faker`: coding/prototyping bot.
- `muyeol`: validation/security bot.

Pitfalls:
- Do not say `TELEGRAM_ALLOWED_USERS` is the bot id; it is the human user's Telegram account id.
- Do not treat absence of optional Telegram env keys as a problem. For 1:1 DM, `TELEGRAM_BOT_TOKEN` + `TELEGRAM_ALLOWED_USERS` is enough.
- If the bot does not answer, check whether that profile's gateway is actually running before debugging token/config.
