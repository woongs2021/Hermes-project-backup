---
name: scheduled-personal-briefings
description: "Design and maintain scheduled personal briefing cron jobs: morning weather/comfort, concise news digests, evening encouragement, and daily markdown logs."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [cron, briefings, personal-assistant, news, weather, markdown-logs]
    created_by: agent
---

# Scheduled Personal Briefings

Use this skill when a user asks Hermes to set up, revise, or troubleshoot recurring personal-assistant routines: daily greetings, weather briefings, concise news digests, end-of-day encouragement, and date-based Markdown work logs.

## Core workflow

1. **Clarify only if needed.** If the requested times, channels, and content are clear, create/update cron jobs immediately.
2. **Check timezone explicitly.** Cron schedules run in the scheduler's timezone/UTC representation. For Korea-local schedules, convert KST to UTC and name jobs with `KST` so the intent remains visible.
   - 09:00 KST → `0 0 * * *`
   - 09:30 KST → `30 0 * * *`
   - 18:00 KST → `0 9 * * *`
   - 23:50 KST → `50 14 * * *`
3. **Use separate cron jobs for separable outputs.** Morning weather, AI news, evening encouragement, and private daily logging should be separate jobs so each can be updated/pause/resumed independently.
4. **Delegate to specialist profiles when the user has an agent team.** If a briefing has an explicit owner profile (for example `yuna` for research / AI×design briefings under Karina orchestration), set the cron job's `profile` field to that profile and make the prompt self-contained about the owner and orchestrator relationship. Verify the updated job shows `profile=<name>` in `cronjob(action='list')`.
4. **Choose delivery intentionally.** User-facing messages use `deliver='origin'`. Private maintenance/logging jobs should use `deliver='local'` unless the user asks to receive them. If the user asks for a briefing to be synced across channels, update the cron job's `deliver` field too (for example `origin,slack` for the current chat plus Slack home channel); memory alone only preserves the preference and does not change scheduled delivery.
5. **Delegate recurring content to specialist profiles when the user has a profile roster.** If a briefing's subject clearly belongs to a specialist profile (for example a research profile owns AI×design paper/news scouting), update/create the cron job with `profile='<specialist>'` and make the prompt explicit that the specialist works under the main orchestrator. Keep the orchestrator accountable for delivery, but let the specialist perform the search/synthesis.
6. **Restrict toolsets for cost and safety.**
   - Weather/news: `web`, optionally `terminal` for date/time.
   - Encouragement-only: usually `terminal` or minimal tools.
   - Daily log synthesis: `session_search`, `file`, optionally `terminal`.
7. **Verify by listing or inspecting cron output after create/update.** Report job names, schedules, profile ownership, and IDs concisely.
6. **Verify by listing or inspecting cron output after create/update.** Report job names, schedules, IDs, delivery target, and any non-default profile concisely.

## Multi-profile ownership

When the user has a specialist-profile team and wants a recurring briefing delegated away from the main/orchestrator profile:

1. Update the existing cron job rather than creating a duplicate.
2. Set the cron job's `profile` field to the specialist profile (for example `profile='yuna'` for research briefings).
3. Rewrite the prompt so the specialist's ownership is explicit while the main persona remains accountable for delivery quality, e.g. “You are Yuna, Chris Park's research agent, working under Karina, the main orchestrator.”
4. Preserve the user's team speech hierarchy in every specialist-owned scheduled prompt: Karina may use warm banmal with Chris; Yuna/Son/Faker and other agents use 존댓말; Muyeol/김무열 uses 극존대.
5. Keep delivery on the user-facing target (`deliver='origin'` unless the user asks otherwise); profile ownership changes who runs the job, not where it is delivered. If the user asks for Slack, set `deliver='slack'` explicitly rather than relying on profile memory.
6. If the user asks to notify the specialist profile of the change, run a one-shot `hermes --profile <name> chat -q ...` instruction and ask that profile to save the durable rule in its own memory; verify the profile reports success.
7. After updating, list/inspect the job and confirm the `profile`, schedule, delivery target, and enabled toolsets are correct.

### Fixed-duration research loops

When the user asks to trial a scheduled research briefing for a limited period (for example “일단 1주일만”):

1. Use finite `repeat` counts for the daily jobs instead of indefinite schedules.
2. If an older recurring briefing would overlap or bias the trial, pause it before creating the trial jobs, and explicitly note that it should be resumed/replaced/retired after review.
3. Create one job per specialist lane rather than merging distinct outputs. Stagger times by a few minutes if both target the same channel.
4. Add a temporary Markdown loop memory file (for example under `/opt/data/agent-team-work-log/<loop>/memory.md`) and require each daily job to append compact sourced entries there.
5. Schedule a one-shot summary/pruning job after the trial that writes a durable weekly summary file, then prunes the temporary memory to distilled leads and next-loop improvements.
6. Schedule a validation/evaluation owner after the summary job (for Chris's team, Muyeol) to review evidence quality, coverage, noise, bias, and whether to continue.
7. If Chris says the loop should validate on Fridays, align the trial end, summary/pruning, and Muyeol evaluation to the next appropriate Friday instead of a strict 7-day cutoff. Keep the daily jobs finite through that Friday and name jobs with the Friday validation intent.
8. Keep “source-led first, product implications second” in the prompt when the user says a briefing has become too product-specific (for example too One UI-centered).
9. For Chris, do not add extra adjacent routines “for completeness” when he asks to save tokens; preserve already-approved care/comfort messages, but avoid unsolicited new work outside the named loop.

### Chris-specific Karina/Yuna cadence pattern

When Chris asks to split recurring design briefings and comfort routines between Karina and a specialist such as Yuna, use this stable operating pattern unless he overrides it:

- **Yuna** owns the daily AI×design/UX/HCI research report as the design-research agent under Karina. Set `profile='yuna'`, use the research/briefing skill, and deliver to Slack when Chris asks for the report to be left there.
- **Karina** keeps Telegram-facing personal care: morning weather + warm note, plus warm notes at morning, lunch, evening, and night. Prompts should lightly consult recent work logs/session context and reflect real work only when evidence exists; never invent a work context just to personalize.
- If multiple jobs naturally land at the same KST time, separate ownership and delivery clearly rather than merging unrelated routines. It is acceptable for Yuna's Slack report and Karina's Telegram morning note to both run at 09:00 KST because they have different profiles/destinations.
- For weekly Slack summaries that synthesize work logs, avoid colliding with the 09:00 morning/report jobs by scheduling a few minutes later (for example Monday 09:15 KST) unless the user specifies an exact time.
- Preserve daily local Markdown/logging jobs separately from user-facing comfort/report jobs; recurring comfort messages should not pollute work summaries except as high-level context if explicitly relevant.

## Prompt patterns

### Morning comfort + weather
- Tone: warm, casual, brief; for this user, Korean “카리나 모드” is appropriate when they address the assistant that way.
- Include location-specific weather bullets.
- Do not store weather details in memory.

### Low-token balanced AI news
The user prefers daily AI news to be balanced but concise.

Prompt constraints:
- Search only enough to find good candidates: usually 2–4 queries.
- Prefer official sources, primary announcements, arXiv, OpenReview, ACM/CHI/UIST/DIS/CSCW, ACL Anthology, major journals/conferences, or major outlets.
- Remove duplicates, rumors, and thin promotional items.
- Balance across model/product, big tech, infrastructure/chips, policy/regulation, and research/papers unless the day’s importance is clearly concentrated.
- For this user's paper/research briefing days, do **not** default to highly technical algorithm/model-performance papers. Prioritize AI × design, UX, HCI, creative tools, interaction design, prototyping, multimodal user experience, emotional/brand/visual design, and human-AI collaboration — especially items that can inspire future One UI and warm, human-centered AI UX.
- Useful paper-day search queries should include design/HCI context, e.g. `AI design UX HCI paper`, `human-AI interaction design CHI`, `generative AI design tools research`, `LLM UX design study`, `multimodal AI interaction design`.
- Return 5 items max.
- Each item should be at most 3 compact lines: title, one-line summary/importance, source link.
- Omit long methodology explanations unless the user asks.

### Specialist-owned AI×design briefing
When a user creates a named research profile for briefings (e.g. `yuna`), update the existing 09:30 KST job rather than creating a duplicate:

- Keep schedule `30 0 * * *` for 09:30 KST.
- Set `profile` to the specialist profile.
- Keep delivery on the user-facing origin unless the user asks otherwise.
- The prompt should explicitly say the specialist is working under the main orchestrator, and should preserve the user's AI×design/UX/HCI/future One UI curation constraints.

### Evening encouragement
- 2–4 Korean sentences.
- Warm and lightly motivating: “조금만 더 힘내자” without adding pressure.
- No weather/news unless requested.

### Daily Markdown work log
- Save date-based files such as `/opt/data/daily-work-log/YYYY-MM-DD.md` unless the user specifies another vault/path.
- Use Asia/Seoul date when the user’s routine is KST-based.
- Exclude routine weather, greeting, and scheduled news content unless the user explicitly wants it included.
- Summarize decisions, work performed, and next actions; do not paste raw transcripts or secrets.
- Consider maintaining an `INDEX.md` with date, summary, and keywords if cross-platform recall from Slack/Telegram is important.
## Specialist-profile ownership

When a recurring briefing becomes owned by a specialist profile (for example, a research agent handles a 09:30 AI/design briefing while the main persona remains the user-facing orchestrator), update the cron job's `profile` field directly. Do not rely on memory or SOUL instructions alone.

Pattern:

1. `cronjob(action='list')` to find the existing job id.
2. `cronjob(action='update', job_id=..., profile='<specialist-profile>', name='KST HH:MM <specialist> ...', prompt='self-contained prompt...', deliver='origin', skills=[...], enabled_toolsets=[...])`.
3. `cronjob(action='list')` again and verify the job shows the intended `profile`.

Keep `deliver='origin'` when the user still expects the same Telegram/Slack delivery. Ownership and delivery channel are separate.

## Cross-platform recall note

Date-based Markdown logs are not automatically injected into every future chat. When the user asks from Slack/Telegram to recall a date or week, read/search the log directory and answer from the files. For higher recall reliability, add an `INDEX.md` and encode the log path in the cron prompt.

## Pitfalls

- Do not treat a Markdown log as long-term memory. Use memory for durable user preferences; use Markdown for dated work records.
- Do not send private daily logs to the user unless requested.
- Do not create a single giant prompt for multiple routines; separate jobs reduce token use and make changes safer.
- Do not over-search daily news. Token efficiency is part of the product quality for recurring digests.
- When the user asks for a scheduled briefing that appears missing or late, inspect the cron job state (`last_run_at`, `last_status`, `last_delivery_error`, `next_run_at`) first. If the scheduled run has not produced user-visible output, do not just say it is scheduled; produce an ad hoc briefing using the same content constraints.
- `cronjob(action='run')` may enqueue/update `next_run_at` rather than returning the final briefing content immediately. After triggering a run, verify whether `last_run_at`/`last_status` changed or whether a message was actually delivered. If not, fall back to manual web/news gathering and answer inline.
- When updating a finite daily briefing after its scheduled time has already passed, verify each lane's `last_run_at`, repeat counter, and loop-memory entry before assuming today's item ran. If a lane missed today's slot, either explicitly backfill it now and verify delivery/memory, or tell the user it was missed and adjust the remaining repeat count so the trial window still ends on the intended validation day.

## References

- `references/kst-telegram-daily-briefing.md` — concrete KST Telegram setup pattern from a session, including schedules and prompt snippets.
