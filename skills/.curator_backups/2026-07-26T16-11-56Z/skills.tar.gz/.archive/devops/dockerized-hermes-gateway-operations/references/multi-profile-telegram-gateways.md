# Multi-profile Telegram gateways

Use when a user wants to talk 1:1 with several Hermes profiles from Telegram, e.g. a main orchestrator plus specialist profiles.

## Recommended shape

Create one Telegram bot per Hermes profile:

- default/Karina: existing bot
- yuna: separate Yuna bot
- son: separate Son bot
- faker: separate Faker bot
- muyeol: separate Muyeol bot

Reason: Telegram polling/webhook delivery is owned per bot token. Reusing the same `TELEGRAM_BOT_TOKEN` across several simultaneously running profile gateways causes conflicts and confusing dropped/competing updates.

## Per-profile env

Each profile has its own `.env`, typically:

- `/opt/data/profiles/<profile>/.env` in the official container/profile layout
- or `$HERMES_HOME/profiles/<profile>/.env` generally

Add the profile's own token and access controls:

```env
TELEGRAM_BOT_TOKEN=<token from BotFather>
TELEGRAM_ALLOWED_USERS=<authorized Telegram user id or comma-separated ids>
# Optional, useful for deliveries/cron:
TELEGRAM_HOME_CHANNEL=<chat id>
TELEGRAM_HOME_CHANNEL_NAME=<friendly name>
```

Never print raw tokens in chat or logs. If showing command examples, use placeholders.

## Starting gateways

Run one gateway process per profile. In a Docker/container foreground pattern, tmux is convenient:

```bash
tmux new-session -d -s gw-yuna  'cd /opt/hermes && source /opt/hermes/.venv/bin/activate && hermes --profile yuna gateway run'
tmux new-session -d -s gw-son   'cd /opt/hermes && source /opt/hermes/.venv/bin/activate && hermes --profile son gateway run'
tmux new-session -d -s gw-faker 'cd /opt/hermes && source /opt/hermes/.venv/bin/activate && hermes --profile faker gateway run'
tmux new-session -d -s gw-muyeol 'cd /opt/hermes && source /opt/hermes/.venv/bin/activate && hermes --profile muyeol gateway run'
```

Use the profile wrapper (`yuna gateway run`, etc.) only if its wrapper directory is on `PATH`; otherwise prefer `hermes --profile <name> ...`.

## Verification

Check:

```bash
hermes gateway list
hermes --profile yuna gateway status
hermes --profile son gateway status
hermes --profile faker gateway status
hermes --profile muyeol gateway status
```

For live process checks, ensure there is only one gateway process per profile/bot token. Inspect each profile's real gateway log and redact tokens before sharing excerpts.

## User-facing instructions

Tell the user to open each bot's DM in Telegram and send `/start`. After that each bot acts like a separate 1:1 channel with its owning profile.
