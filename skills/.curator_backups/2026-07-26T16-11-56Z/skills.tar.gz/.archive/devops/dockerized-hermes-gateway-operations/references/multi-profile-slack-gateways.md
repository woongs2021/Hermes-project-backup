# Multi-profile Slack gateways

Session-derived pattern for putting several Hermes profiles into one Slack channel as a working agent team.

## Goal

Run one Slack bot per Hermes profile so a shared Slack channel can contain multiple specialist agents (for example Karina/default, Yuna, Son, Faker, Muyeol) without token or event-routing collisions.

## Stable pattern

1. Create one distinct Slack App per profile. Do not share `SLACK_BOT_TOKEN` or `SLACK_APP_TOKEN` across running gateways.
2. Enable Socket Mode for each app and create an app-level token with `connections:write`.
3. Add bot scopes appropriate to the channel type. Common scopes:
   - `app_mentions:read`
   - `chat:write`
   - `channels:history`, `channels:read` for public channels
   - `groups:history`, `groups:read` for private channels
   - `im:history`, `im:read`, `im:write`
   - `mpim:history`, `mpim:read`
   - optional: `reactions:write`, `files:read`, `files:write`
4. Subscribe the app to relevant bot events, typically:
   - `app_mention`
   - `message.im`
   - `message.channels`
   - `message.groups`
   - `message.mpim`
5. Install or reinstall each app to the workspace after scope/event changes.
6. Add profile-specific secrets to `/opt/data/profiles/<profile>/.env`:

```env
SLACK_BOT_TOKEN=xoxb-...
SLACK_APP_TOKEN=xapp-...
SLACK_REQUIRE_MENTION=true
```

7. Keep `SLACK_REQUIRE_MENTION=true` in multi-agent shared channels so only the mentioned agent responds. This prevents a noisy pile-on where every profile answers every message.
8. Restart only the profile gateways whose `.env` changed. In the official container, stop the existing manual profile process first, then start a fresh tracked long-lived background `hermes --profile <profile> gateway run` and verify.
9. Invite every bot to the same Slack channel and test with explicit mentions.

## Verification signals

For each profile, verify all of the following from sanitized status/log output:

- `Gateway is running (PID: ...)`
- `✓ telegram connected` if Telegram remains configured for that profile
- `Authenticated as @<bot-name> in workspace ...`
- `Socket Mode connected`
- `✓ slack connected`
- `Gateway running with 2 platform(s)` when both Telegram and Slack are configured

## Secret handling

Never print raw Slack or Telegram tokens. Validation output should only report presence/format and maybe a tiny redacted prefix. Scrub:

- Telegram: `[0-9]+:[A-Za-z0-9_-]+`
- Slack bot: `xoxb-...`
- Slack app: `xapp-...`

## Operational notes

- A profile can run Telegram and Slack from the same gateway process if both platform credentials are present in that profile's `.env`.
- If the process was already running before `.env` changed, the new Slack variables will not be picked up until that profile gateway restarts.
- `hermes --profile <profile> gateway status` may list other running profiles; use this to avoid duplicate launches.
- Logs may show bot display names like `@hermes2`, `@hermes3`; use those names when inviting/testing if the desired display names have not been customized in Slack.