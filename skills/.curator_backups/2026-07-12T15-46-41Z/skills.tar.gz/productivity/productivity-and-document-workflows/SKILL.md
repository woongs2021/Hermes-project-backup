---
name: productivity-and-document-workflows
description: "Use when operating productivity apps, documents, personal knowledge systems, maps, briefings, meeting pipelines, PDFs/OCR, presentations, email-like workspaces, Airtable, Google Workspace, Notion, and scheduled personal automation."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [productivity, documents, google-workspace, notion, airtable, pdf, ocr, powerpoint, briefings, meetings, knowledge]
    related_skills: [research-intelligence-workflows]
---

# Productivity and Document Workflows

## Overview

This umbrella covers user-facing productivity systems: office documents, knowledge bases, scheduled briefings, personal/persona calibration, map/location lookups, meeting pipelines, and SaaS workspaces such as Google Workspace, Notion, and Airtable. The common pattern is to authenticate safely, retrieve or mutate real external state, verify with a read-back, and return a durable link/path/record ID.

## When to Use

- The user asks for Google Drive/Docs/Sheets/Gmail/Calendar operations, Notion pages/databases, Airtable records, or similar productivity app work.
- The user asks to create/edit/read PowerPoint decks, PDFs, scanned documents, OCR output, or document conversions.
- The user asks for scheduled personal briefings, meeting summaries, Teams pipeline operation, daily work wikis, or Obsidian/vault updates.
- The user asks for geocoding, POIs, routes, time zones, or Telegram location-pin interpretation.
- The user asks to calibrate assistant persona/preferences in a durable but non-overfit way.

## Core Workflow

1. **Identify the system of record.** Google, Notion, Airtable, local vault, PDF/PPTX file, map API, cron job, or meeting pipeline.
2. **Check auth and prerequisites.** Do not invent tokens, IDs, or file paths; inspect config/env when needed.
3. **Perform the action with the narrowest tool.** Prefer CLI/API wrappers already configured for the workspace.
4. **Read back after writes.** Fetch the record/page/file/cron job again, or inspect generated output.
5. **Return a durable handle.** URL, document ID, file path, cron job ID, meeting ID, route summary, or extracted text path.

## Workflow Lanes

### SaaS workspaces and data apps

- Google Workspace: use gws/Google API helpers for Gmail, Calendar, Drive, Docs, and Sheets; respect OAuth setup and scopes.
- Notion: use ntn CLI or HTTP API; distinguish databases/data sources/pages and preserve property schemas.
- Airtable: handle field types carefully, paginate, use formulas for filters, and verify upserts by record ID.
- Social/email tools such as Himalaya or X/Yuanbao/OpenHue are usually separate integration lanes, but the same rule applies: act through the configured CLI/API and read back.

### Documents and presentations

- PowerPoint: inspect structure, edit XML or use helper scripts, then render/QA slides when possible.
- PDF/OCR: try remote extraction for accessible URLs, then local PyMuPDF for digital PDFs, then marker/OCR for scans.
- Nano-PDF: use for targeted text/title typo edits, not full redesigns.
- Keep original files backed up before destructive edits.

### Personal knowledge, briefings, and meetings

- Scheduled personal briefings: use cron jobs with self-contained prompts; respect multi-profile delivery/ownership.
- Daily work wiki and Obsidian: write concise, dated notes with links back to sources or session references.
- Persona calibration: save stable user preferences, not transient task outcomes; avoid overfitting to one chat.
- Teams meeting pipeline: inspect status, replay or summarize jobs, and remember Graph subscriptions expire quickly.

### Maps and location

- Geocode, route, and timezone through OpenStreetMap/OSRM-style APIs or configured map scripts.
- Include coordinates, timestamp/source, and assumptions about travel mode.
- For chat location pins, parse the platform metadata rather than asking the user to retype coordinates when available.

## Consolidated Legacy Knowledge

- `airtable`: REST CRUD, filters, field shapes, pagination, and upserts.
- `google-workspace`: Gmail/Calendar/Drive/Docs/Sheets via gws CLI and Python bridge.
- `notion`: Notion API, ntn CLI, database/data-source changes, and markdown conversion.
- `powerpoint`: PPTX creation, reading, targeted editing, helper scripts, and QA.
- `nano-pdf`: natural-language PDF typo/title edits.
- `ocr-and-documents`: PDF/scanned document extraction with PyMuPDF/marker and arXiv handling.
- `maps`: geocoding, POIs, routes, timezones, and Telegram location pins.
- `scheduled-personal-briefings`: cron prompts, delivery routing, morning/evening/daily digest patterns.
- `teams-meeting-pipeline`: Teams meeting summary pipeline operation and Graph subscription pitfalls.
- `daily-work-wiki`: durable daily work/conversation wiki architecture.
- `obsidian`: vault read/search/write/edit patterns and wikilinks.
- `persona-calibration`: onboarding questions and stable preference memory hygiene.
- `himalaya`: terminal IMAP/SMTP operations when email work is document/productivity adjacent.

## Common Pitfalls

1. **No read-back after mutation.** External writes must be verified before reporting success.
2. **Confusing transient logs with durable memory.** Save only stable preferences; put task logs in notes/wiki/session search.
3. **Flattening documents.** PPTX/PDF/Notion blocks have structure; preserve it rather than dumping plain text unless asked.
4. **Credential leakage.** Never echo OAuth tokens/API keys; use configured tools and redact secrets.
5. **Wrong profile ownership.** Scheduled briefings and meeting pipelines may belong to specialist profiles; inspect before editing.

## Verification Checklist

- [ ] System of record and target object identified.
- [ ] Auth/prerequisites checked.
- [ ] Operation executed with configured CLI/API/file tool.
- [ ] Mutation read back or generated file inspected.
- [ ] Durable URL/path/ID and caveats returned.
