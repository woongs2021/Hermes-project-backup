---
name: hermes-agent-team-operations
description: "Use when configuring Hermes multi-profile agent teams, specialist profiles, Kanban orchestration, worker routing, and scheduled ownership patterns."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, profiles, agent-teams, kanban, orchestration, specialists]
    related_skills: [hermes-agent]
---

# Hermes Agent Team Operations

## Overview

This umbrella covers operating Hermes as a team of profiles and workers: specialist profile setup, role routing, Kanban-based delegation, orchestrator behavior, worker lifecycle, and scheduled ownership. Use it when the task is about coordinating multiple Hermes agents rather than a single chat session.

## When to Use

- Creating or verifying multi-profile Hermes teams with role-specific models, credentials, wrappers, or smoke tests.
- Configuring a main orchestrator profile that routes work to specialist profiles.
- Using Kanban boards to decompose, assign, monitor, and recover work.
- Writing cron delegation patterns or scheduled ownership rules for specialist agents.

## Multi-Profile Team Setup

- Define roles first: what each specialist owns, what credentials it needs, and what model/tool profile it should use.
- When splitting an existing specialist lane, update both sides: the new profile's `SOUL.md`, the old peer's narrowed `SOUL.md`, and Karina/default routing rules so the team does not keep duplicate broad mandates.
- Create wrappers and profile config explicitly; do not assume a fixed roster.
- For independent Telegram/Slack bots, create a private profile `.env` template with blank token slots and `0600` permissions; never copy or print another profile's real tokens.
- Smoke test each profile independently before wiring orchestration.
- Keep credentials/profile isolation clear so one specialist does not accidentally inherit another's state.
- Detailed checklist: `references/adding-specialist-profile-with-independent-gateway.md`.
- Smoke test each profile independently before wiring orchestration.
- Keep credentials/profile isolation clear so one specialist does not accidentally inherit another's state.
- For the session-proven checklist for adding a named specialist and splitting a research lane, see `references/adding-specialist-profile-role-split.md`.
- For the follow-up env-template and verification pattern, see `references/specialist-role-split-profile-addition.md`.

## Orchestrator Routing

- The orchestrator should route work, set context, and verify results; it should not silently do all specialist work itself.
- For future implementation assets such as agent profile images, homepage portraits, logos, and visual handoff files, keep a stable asset folder plus `MANIFEST.md`; if Chris manually renames files, re-audit the folder and update the manifest from the current filenames rather than earlier cache names. See `references/team-asset-handoff-and-manifest.md`. 
- Use routing rules that include task class, target profile, expected output handle, and verification step.
- For scheduled ownership, cron prompts must be self-contained because they run without current chat context.
- For specialist-owned outbound Telegram/Slack delivery, create the cron job in the specialist profile's own cron store (e.g. `hermes --profile son cron ...` or with `HERMES_HOME=/opt/data/profiles/son`) and use that profile's gateway. Merely setting `profile: son` on a default/Karina cron job can run the prompt as Son while still delivering through the default/Karina gateway/live adapter, making the message appear from Karina. If a specialist job must remain in the default cron store, set cron `deliver=local` and make the profile-run prompt send the user-facing DM directly through that specialist profile's bot token, without printing credentials or falling back to Karina delivery. Ensure the job has a direct-send-capable toolset such as `terminal`; otherwise it can prepare local content but fail to send. See `references/direct-specialist-telegram-delivery.md`.
- For specialist Telegram DM cron jobs, prefer explicit targets such as `telegram:<chat_id>` (or the platform:chat_id:thread_id form when needed) instead of bare `telegram`. Bare platform delivery can fail in profile-owned cron stores if no origin/home target resolves, even when the profile's gateway and channel directory know the user. After changing a missed-delivery job, clear/verify stale `last_delivery_error`, run it once, and confirm the scheduler log says it delivered via the live adapter before telling Chris it is fixed.
- When the user splits an existing specialist lane, update/confirm all three surfaces: the old specialist's narrowed mandate, the new specialist's mandate, and the orchestrator's routing/memory/log schema.
- For Chris's research team, route AI technology/paper/startup/future-scenario work to Yuna and UX research/interviews/competitive service/design benchmark/IA journey/Persona-JTBD/design insight to Go Youn-jung; Karina synthesizes for decisions rather than letting parallel voices replace leadership.
- **Cost-minimizing default for Chris:** Karina is the single front door and must classify before calling specialists. Prefer Level 0/1 answers from rules, memory, and Karina's own synthesis for simple questions, emotional support, quick direction, and low-risk decisions. Use Level 2 (one specialist) only when a lane is clearly needed; Level 3 (max two specialists) only for high-risk, ambiguous, or production-critical work; Level 4/full-team calls are exceptional.
- Do not summon all agents by default, do not ask the same question to multiple agents unless running a justified review, and do not run research/validation loops for every response. Each extra specialist call adds model-call, context-transfer, and synthesis cost.
- Specialist triggers for Chris: Faker only for actual code edits/debugging/terminal execution; Go Youn-jung for external UX research, competitive analysis, design research synthesis, professional visual design artifacts, diagrams/infographics/cards, design-system visual structure, and Higgsfield prompt/result critique; Son for scope, prioritization, schedule, and roadmap judgment; Muyeol for pre-release validation, security/privacy, critical-error checks, and go/no-go risk review.
- For Chris-facing performance or orchestration explanations, Karina should keep warm banmal even when explaining technical/team tradeoffs. Avoid slipping into formal report-style 존댓말; summarize as “작은 건 내가 바로, 필요하면 한 명만, 위험하거나 애매할 때만 두 명, 전체 팀은 거의 안 부름.”

### Direct-to-specialist task reporting loop

When Chris gives work directly to a specialist in DM or Slack, do not let that bypass Karina's shared situational awareness:

1. The specialist should report back to Karina with: requested task, key context, their current understanding, planned next action, and blockers/decisions needed.
2. Karina should DM Chris a concise synthesis: what Karina understood, which specialist owns it, the next action, and any blocker or decision.
3. Encode this rule in both Karina/default and specialist profile instructions when setting up or repairing the team; Slack reminders alone are not enough.
4. Preserve tone hierarchy: Karina may use warm banmal with Chris; specialists use 존댓말; Muyeol uses 극존대.

#### Specialist-to-specialist handoff via Karina

When a specialist (for example Son) has already summarized a request in Slack and asks Karina to route it to another specialist (for example Go Youn-jung), Karina should actively complete the handoff rather than merely acknowledging it:

1. Locate or use the original Slack handoff thread/message when available, and reply in-thread so context stays attached.
2. Compress the source specialist's request into: user goal, source material, target artifact, audience/channel, design/quality direction, and acceptance criteria.
3. Explicitly assign the receiving specialist, name the delivery path (for Chris, usually DM), and require a verifiable completion handle back to Karina (file path, image URL, Slack/Telegram message ID, or concise status if blocked).
4. If the task is visual/design-oriented, include concrete design-system expectations such as information hierarchy, typography, spacing, semantic color, component/card structure, and density/legibility constraints.
5. Record substantive routing in Karina's daily team work log when it affects multi-agent continuity.

- When Chris asks for a future-dated growth program or role-development goal, delegate the planning lane to Son first, then have Karina synthesize: goal interpretation, preparation timeline, first learning/execution loop, and ≤3 clarification questions. Save Son's plan path and Karina's synthesis in the team work log.

### Scheduled research briefing formatting

When updating Chris's recurring 3+3 research/paper briefing jobs, treat legibility as part of the operating contract, not a cosmetic afterthought.

- Keep the active 3+3 paper pipeline aligned across all four jobs: Yuna daily AI-paper picks, Go Youn-jung daily UX/design-paper picks, Karina Friday shortlist prep, and Muyeol Friday final validation.
- Keep the active paper pipeline aligned across the relevant jobs: Yuna daily AI-paper picks, Go Youn-jung daily UX/design-paper picks, Karina Friday shortlist prep, Muyeol Friday validation/report draft, and Karina Friday final delivery. If Son or dashboard follow-up jobs reference the weekly report shape, update those too.
- Chris's current Friday weekly paper report format is **best 3 total across Yuna + Go Youn-jung weekly findings**, not the old 3+3/6-item format. Daily research can still collect multiple candidates per lane; Friday curation must reduce them to exactly 3 selected items overall.
- If Chris changes a format rule, patch all relevant cron prompts in the same pass and verify the rule is present before reporting completion.
- De-duplicate visible paper items before delivery. Normalize title, DOI, arXiv/OpenReview/ACM/venue ID, URL, and obvious same-paper variants; if the same paper appears in multiple searches or earlier weekly candidate files, show it only once and treat repeat appearances as weighting/relevance/confidence signal in scoring and notes.
- Preserve the existing content constraints while changing formatting: exactly 3 selected items total for the weekly report, clear rationale for why those 3 were chosen, Chris relevance rather than forced One UI framing, credible Korean-source coverage when it genuinely ranks or adds local context, concise Korean, source/reference links, and Muyeol GO/HOLD/WATCH cautions.
- If the weekly paper report feeds Go Youn-jung's visual job, keep the visual job aligned too: source of truth is Muyeol's final best-3 report; current output is **one directly generated 1:1 abstract metaphor image via Higgsfield plus the exact prompt used**. Do not produce SNS/Instagram carousel prompt packs or four-slide Midjourney prompts unless Chris explicitly restores that lane. Use woongdesignv2 only as a restraint/material/editorial-quality reference, keep the quality bar “AI티가 안 나는 것,” and store production notes, image path/URL, exact prompt, quality notes, and limitations under `/opt/data/agent-team-work-log/visuals/YYYY-WW/`. The final visual delivery must also include a concise **“왜 이 그림인가”** rationale that ties the image to the weekly best-3, Muyeol's caution/validation lens, the chosen metaphor, and how Chris should read it. Require deliberate style variation: before generating, check previous visual notes when available and vary at least a few of metaphor, composition logic, material texture, color temperature, art/reference movement, density, lighting, and spatial depth so the weekly abstract image does not repeat the same look. For profile-owned generation, verify Higgsfield auth/workspace under the target profile's `HOME` before testing; if sharing the default Higgsfield account with a specialist profile is intended, copy only `.config/higgsfield` config/credential files with `0600` permissions and never expose raw tokens.
- If Chris wants a specialist-owned short weekly-report summary in addition to Karina's full report, keep Karina as the full-report owner and create downstream specialist crons using `context_from` Karina's final report job. Current Chris pattern: Muyeol produces a **local validation summary for Son** (not a user DM), then Son owns the user-facing weekly DM as PM/growth/SNS marketer. Son's DM should use Korean `~다` declarative style, start every summary bullet/sentence line with an emoji, include one sentence explaining why the final 3 were selected, add one SNS/marketing angle for Instagram/Facebook/LinkedIn/Threads, and append a compact “선정 논문 3개” section with exactly three emoji-led lines containing Korean-translated title + original title + Telegram-compatible Markdown hyperlink when a URL exists. Never fabricate missing links—write the title and “링크 확인 필요다” instead.
- When a format preference is durable, update affected briefing cron prompts plus relevant user preference memory and skill guidance; verify the rule is present in Muyeol Friday shortlist/candidate-pool prep, Muyeol Friday validation/report draft, Karina final delivery, downstream Muyeol summary DM, and any downstream Go Youn-jung/Son/dashboard jobs before reporting completion. Record substantive briefing-rule changes in Karina's daily team work log.

### Research-to-growth reporting loops

When Chris wants daily research to grow him rather than merely inform him, structure the loop as a team-owned growth system:

- Keep daily Yuna/Go Youn-jung research source-led and lightweight.
- Son owns growth-question framing and the user-facing “오늘의 성장 질문” / SNS subscriber-growth DM. Do **not** insert Karina as a daily growth-framing step unless Chris explicitly asks; Karina's personal scheduled loops should remain her original weather/greeting loops.
- Have Muyeol provide a compact local pre-flight guardrail for Son rather than rewriting Son's question: overclaiming, privacy, emotional/sensitive-topic risk, psychological safety, forced One UI linkage, and premium tone.
- Son sends the final “오늘의 성장 질문” 1-2 questions to Chris in Son's Telegram DM. Questions should be answerable in 1-3 minutes.
- Son's growth questions should include compact source tags plus a short reason so Chris can see whether a question comes from his prior answers, OBD framing, PM/business judgment, research/papers, or brand/design-management reasoning.
- When Chris assigns Son a professional marketer role, clarify the growth target. If Chris frames the target as **Hermes growth story → SNS communication → subscriber/follower acquisition**, make that the primary objective of the daily Son DM, not a generic `SNS 마케팅 팁` add-on. The message should help Chris publicly narrate his real Hermes-building journey with trust, usefulness, continuity, and design quality.
- The current Son daily SNS/subscriber loop pattern: Son DMs Chris at 09:50 KST with one growth question, one concrete SNS/subscriber conversion tip, one 10–20 minute experiment, and one OBD/productization note. It accumulates data under `/opt/data/hermes-growth-sns-loop/` so future OBD, coding, wiki, homepage, and dashboard work can reuse the signals. See `references/hermes-growth-sns-subscriber-loop.md`.
- If Chris asks to reactivate or update the daily Son loop, update the active Son cron prompt itself, not only Karina memory: make Son the owner of growth-question framing, include `context_from` Muyeol guardrail/governance jobs when useful, resume the paused job, and if Chris asks for “today too,” trigger `cronjob(action='run')`. After triggering, distinguish **queued/triggered** from **delivered** unless `last_run_at`/`last_status`, created loop artifacts, or the user-visible message confirms delivery; scheduler ticks can run asynchronously.
- Son should log source flow for delivered daily questions and SNS/subscriber experiments in structured local files so Faker can later build a dashboard over question origins, upstream refs, OBD themes, research IDs, subscriber hypotheses, and experiment outcomes. Legacy question-source logs may live under `/opt/data/agent-team-work-log/growth-question-sources/`; the Hermes-growth SNS loop uses `/opt/data/hermes-growth-sns-loop/`.
- For Son-owned outbound delivery from Son's profile, make the delivery target explicit when necessary (for example `telegram:<Chris chat id>` from Son's profile cron store) rather than relying on bare `telegram`, because profile-local cron may not resolve a home target even when the channel directory contains the DM.

- When Chris reframes the growth target, patch every active surface in the loop, not just the default/Karina cron: relevant specialist `SOUL.md` files, daily research prompts, Karina framing prompts, Son active profile cron prompts, paused/default backup jobs if likely to be resumed, weekly shortlist/report prompts, and any local profile/career context files.
- When Chris wants a recurring education-oriented loop about AI/AX job-market change, chain the agents rather than asking every agent the same broad question: Yuna researches AI/AX effects on jobs across Korea/global; Go Youn-jung narrows that evidence to design-role impact; Son translates both into business-market shifts; Faker consolidates into tab/log structures without starting UI implementation; Muyeol validates on Friday only. Keep intermediate reports local and send only explicit validation/synthesis to Chris unless requested. See `references/ai-ax-job-shift-education-loop.md`.
- If Chris sets Chris relevance toward OBD / Ontology Business Designer, treat relevance as business-centered design leadership: UX/design insights should be evaluated for market/category framing, customer value, brand/business strategy, design management, ecosystem/service model, value exchange, adoption, and organizational decision quality. Avoid generic startup/finance language; translate implications into Chris's design-leadership vocabulary.
- Weekly Karina reports should combine the best-3 weekly selections, Muyeol validation, and Chris's actual answers to Son. If answers are sparse, say so and avoid inflated growth claims.
- Monthly reports should run on the last day of each month, regardless of weekday. If the scheduler lacks an `L` cron day, use a daily cron plus script guard that stays silent unless tomorrow's KST day is `01`.
- For the session-proven operating pattern, including monthly script-guard and future UI handoff to Faker, see `references/research-growth-reporting-loop.md`.

### Time-boxed multi-agent learning loops

Use this pattern when Chris asks to “loop engineer” a process for one week before deciding whether to make it permanent:

1. Define lane owners, source scope, output count, delivery channel, and trial window.
2. Pause any older scheduled job whose output would duplicate or bias the trial.
3. Create finite-repeat daily jobs for each owner, with prompts that require compact sourced entries and clear handoff signals back to Karina.
4. Store accumulated findings in a temporary Markdown loop memory under the agent-team work-log root, not in durable `memory`, because the details are date-bound and meant to be pruned.
5. Schedule Karina to write a weekly synthesis and prune the temporary loop memory.
6. Schedule Muyeol after Karina's synthesis to evaluate evidence quality, coverage, noise, bias, and go/no-go recommendations for the next week.
7. If Chris wants Friday to be the recurring validation checkpoint, extend or align the first trial to the next Friday rather than ending the loop too early; update daily repeat counts, summary dates, evaluation dates, filenames, and loop-memory date ranges together.
8. After changing schedules/repeat counts mid-loop, audit every specialist lane for missed first-run windows: compare `last_run_at` and the shared loop-memory entries, not just `next_run_at`. If one specialist ran and another did not, report that plainly, avoid pretending delivery happened, and either verified-backfill or adjust the remaining runs.
9. Report the loop as experimental and reversible; do not automatically continue it past the requested trial without evaluation.
10. When Chris says to conserve tokens or not do other work, keep only the explicitly approved loops and Karina comfort/psychological-stability messages; do not proactively expand scope with extra agents, extra reports, or extra diagnostics.
11. For low-token specialist coding loops, especially Faker-owned project work under Chris's GPT Plus-style budget, schedule one small verified coding objective per day from the specialist profile's own cron store, use explicit Telegram delivery, require short daily DM reports, and schedule a Friday evening Muyeol coding addendum if the normal Friday morning report happens before the week's coding is complete. For dashboard/UI skeleton work, carry Chris's design direction into every relevant daily cron prompt, not only the styling day: use woongdesignv2 colors/tokens with clean high-end SaaS/bento admin-dashboard references (light canvas, rounded cards, soft shadows, generous spacing, restrained typography, calm metric/list panels) and explicitly avoid neon, glassmorphism, fake 3D, and generic AI-startup aesthetics. See `references/low-token-specialist-coding-loop.md`.
12. When Chris wants a future Faker coding loop but explicitly delays implementation, encode the phase boundary in the active cron prompt and local schema: before the start date, collect only data structures, IA/routes, components, backlog candidates, OBD reuse notes, and risks; after the start date, implement only once repo/workdir and public/private scope are confirmed. For the current Hermes/OBD webapp pattern, July is planning-only and August is implementation-ready; see `references/faker-webapp-structure-planning-loop.md`.

### Growth-loop planning with PM and validation handoff

When Chris defines a future growth goal (for example becoming an ontology designer), treat it as a compact team planning loop rather than immediate content production:

1. Ask Son to translate the goal into a 4-week operating plan: goal statement, schedule, weekly outputs, token-saving rhythm, and success criteria.
2. Preserve Chris's framing exactly when it shifts the goal. For ontology-designer growth, the focus is conceptual growth around understanding the world, understanding work, and communicating with stakeholders—not making polished design artifacts.
3. If the growth story should later become education content, add a light education-storytelling layer: each week captures a model-diagram fragment plus a short education story card, not a full lecture deck.
4. Schedule Muyeol for final review before presenting the plan to Chris when the plan will guide ongoing work. Ask Muyeol to check scope creep, weak logic, privacy/security/reputation risk, overclaiming, and realism under token constraints.
5. Karina's final report should synthesize Son + Muyeol into a calm DM: final goal, weekly loop, operating rhythm, artifact, education layer, review result, and next start date.
6. See `references/ontology-designer-growth-loop.md` for the session-proven pattern.

## Kanban Orchestrator

- Use the board when work is decomposable, long-running, or benefits from independent specialist ownership.
- Write cards with clear acceptance criteria, relevant files/URLs, and expected artifacts.
- Track stuck workers through heartbeats, block reasons, and recovery steps.

## Kanban Worker

- Workers should claim only work they can actually execute in their workspace/profile.
- Good updates include status, evidence, output handles, and next blockers.
- Respect tenant/profile isolation and avoid mutating shared state without explicit scope.

## Operational Status and Inventory Checks

When Chris asks whether the gateway/team is connected, or what skills the current profile has, treat it as a compact operational check rather than a full diagnostic report.

- Check live gateway/platform/profile status, then summarize in concise Korean banmal.
- For multi-profile gateway checks, verify both the default/Karina gateway and specialist profile gateways. A good compact sequence is: `hermes gateway status`, `hermes status --all`, `send_message(action='list')` for platform target discovery, then per-profile `hermes --profile <name> status --all` only if Chris asked about the team or specialists.
- If inspecting gateway logs, read only recent relevant lines and sanitize secrets before any excerpt; never print raw Telegram/Slack/OAuth/API tokens or mirrored long logs.
- Interpret Slack Socket Mode reconnect warnings carefully: `Socket Mode unhealthy ... reconnecting` means the adapter saw a transport disconnect and is trying to recover; do not call it “down” if the gateway process is still running and Slack targets/status remain configured. Report it as “running, with recent reconnect warnings” unless a send/receive smoke test fails.
- Distinguish configured/running status from end-to-end delivery. If Chris wants certainty beyond configuration, offer or perform a short test message to Telegram/Slack instead of over-explaining diagnostics.
- Distinguish active skills from archived skills, and label authorship/provenance uncertainty when `created_by` metadata is absent.
- See `references/gateway-and-skill-inventory-checks.md` for the session-proven gateway status and skill inventory reporting pattern.

## Common Pitfalls

1. **No smoke tests.** A team config is not real until each profile can run its intended tools.
2. **Orchestrator temptation.** Routing work through Kanban fails if the orchestrator keeps doing the work itself.
3. **Thin cards.** Workers need enough context to act without guessing.
4. **Cron prompts with hidden dependencies.** Future runs do not remember the current chat.
5. **Overlapping specialist lanes.** When adding a specialist to split another agent's workload, patch the old agent, the new agent, and Karina's routing rules in the same pass.
6. **Credential leakage during setup.** Verify `.env` files with set/empty or length checks only; never print raw Telegram/Slack tokens. Each profile needs distinct bot/app credentials.
7. **Assuming service start works everywhere.** In containerized Hermes deployments, `gateway start` may be inapplicable; run the profile gateway as a tracked background `gateway run` process and verify status/logs instead.

## Slack Team-Channel Rules

For a shared Slack channel containing Karina plus specialist profile bots:

- Configure one Slack App/Bot per profile; never share `SLACK_BOT_TOKEN` or `SLACK_APP_TOKEN` across running gateways.
- Create a private per-profile `.env` template before token entry, with platform token slots and restrictive file permissions; never copy another profile's real tokens.
- Set `SLACK_REQUIRE_MENTION=true` for all specialist profiles so the channel does not become noisy.
- If Chris wants a team-wide summon, support Slack broadcast mentions (`@everyone`, `@channel`, `@here`) as wake words for all bots while keeping ordinary messages mention-gated. See `references/slack-broadcast-mention-team-wakeword.md`.
- Put team-channel operating rules in each profile's `SOUL.md`:
  - Karina/default is the single front door, final synthesizer, and coordination lead.
  - Specialists answer in their lane, report handoff notes to Karina, and avoid taking over other specialists' roles.
  - If Chris mentions a specialist directly, the specialist may answer directly while still framing output for Karina's final synthesis.
  - If Chris gives a task directly to a specialist in DM or Slack, the specialist must report the task, key context, their understanding, next action, and blockers back to Karina. Karina then DMs Chris with her concise understanding/synthesis so Chris does not have to track every specialist thread manually.
- Restart every affected gateway after SOUL, env, or Slack adapter/code changes so cached sessions use the new defaults.

- Restart every affected gateway after SOUL, env, or Slack adapter/code changes so cached sessions use the new defaults.

## SOUL.md Localization and Edits

When Chris asks to translate, rewrite, or update `SOUL.md` content for the agent team:

- First discover the likely scope: default `/opt/data/SOUL.md`, profile SOUL files under `/opt/data/profiles/*/SOUL.md`, and any legacy/alternate lowercase files such as `karina-soul.md` when relevant.
- If the request says “soul.md” without naming profiles, default to the active/default Karina SOUL, but report the exact file changed and offer to continue with profile-specific SOUL files.
- If Chris says he wants all of them, update every active profile SOUL under `/opt/data/profiles/*/SOUL.md` in the same pass, not just Karina/default.
- Preserve operational meaning exactly: role boundaries, routing levels, Slack/Telegram behavior, secrecy rules, daily work-log rules, and tone hierarchy should survive translation.
- Korean localization is safe for Hermes operation because `SOUL.md` is Markdown prompt/instruction text, not executable code or a strict machine config. Keep code spans, file paths, profile names, environment variable names, and slash commands unchanged.
- After writing, read back the changed file(s) to verify the rewrite landed and that headings/paths/code spans remained intact. Also run a targeted search for common leftover English instruction headings/phrases when translating multiple profiles.
- Tell Chris that already-running sessions/gateways may keep cached startup instructions; use `/reset` or restart affected gateways for the localized SOUL files to take effect cleanly in new sessions.
- For substantive SOUL changes, update Karina's daily team work log with a compact note: what changed, which file, verification performed, and any remaining profile files not yet touched.

## Daily Agent Work Logs

When the user wants agents to learn from their own work without polluting durable memory:

- Prefer Markdown work logs, not `memory`, for date-bound task progress.
- Use a central root such as `/opt/data/agent-team-work-log/` with per-agent folders (`karina/`, `yuna/`, `goyounjung/`, `son/`, `faker/`, `muyeol/`).
- Add a schema (`SCHEMA.md`) that forbids raw logs, secrets, bot tokens, private IDs, placeholder notes, and no-work notes.
- Chris's current localization preference: future loop logs should be Korean where safe. Patch active cron prompts/scripts that write Markdown, JSON/JSONL human-readable values, TXT summaries, work notes, or local loop logs to use Korean for human-facing content while preserving JSON keys, enum/status values, IDs, file paths, URLs, code identifiers, component/route names, commands, and quoted source titles/strings exactly. If a schema requires English field names, keep field names and translate only explanatory values.
- Add profile SOUL rules: create/update `daily/YYYY-MM-DD.md` only on days with substantive work; if the agent only greeted, performed a platform check, or did no work, write nothing.
- For reliability, add local-only daily cron jobs per profile near end-of-day KST. Each job should use `session_search`, inspect that profile's conversations for the day, and skip file creation when no substantive work occurred.

## Session References

- `references/slack-telegram-profile-team-orchestration.md` — concise session-proven pattern for Karina-led specialist profiles across Telegram 1:1 bots, shared Slack team channel, SOUL.md defaults, per-agent daily Markdown logs, and gateway verification/watch-pattern hygiene.
- `references/direct-specialist-task-reporting-and-growth-planning.md` — pattern for specialist-to-Karina reports when Chris directly assigns work, plus Son-led planning for future-dated role/growth programs.
- `references/direct-specialist-change-sync-son-faker.md` — session-proven pattern for syncing direct Son/Faker changes back into Karina memory, actual profile cron prompts, and team work logs; covers Son question source tags and Faker’s future 3+3/OBD LLM-wiki/dashboard handoff.
- `references/son-sns-marketer-weekly-summary.md` — current pattern for Son as PM/growth + SNS marketer: daily `SNS 마케팅 팁`, Friday Son-owned emoji-led `~다` summary DM, Muyeol local validation input, and selected-paper title/link formatting.
- `references/hermes-growth-sns-subscriber-loop.md` — daily Son DM loop for turning Chris's Hermes growth journey into SNS/subscriber acquisition experiments and structured data for future OBD, coding, wiki, homepage, and dashboard work.
- `references/faker-dashboard-planning-with-source-lineage.md` — planning pattern for Faker’s future 3+3/OBD LLM wiki + dashboard: Son question source-lineage JSONL, dashboard phase-history logging, woongdesignv2 design direction, and no-implementation-before-Chris-approval guardrail.
- `references/faker-webapp-structure-planning-loop.md` — daily Faker DM loop for Hermes/OBD webapp structure planning: July accumulates data/IA/component/backlog candidates under `/opt/data/hermes-webapp-build-loop/`; August can shift to implementation after repo/scope confirmation.
- `references/harness-loop-graph-engineering-webapp-framing.md` — Chris's current product framing for the Hermes/OBD webapp: explain it as Harness / Loop / Graph Engineering, position Hermes as the harness rather than the only possible implementation path, start graph work as a file-based `nodes.jsonl`/`edges.jsonl` MVP, and add “why Hermes” copy to the future project intro.
- `references/harness-loop-graph-engineering-webapp-framing.md` — Chris-approved framing for Hermes/OBD webapp as Harness / Loop / Graph Engineering, with a modest file-based graph MVP before KuzuDB/Neo4j.
- `references/direct-specialist-telegram-delivery.md` — direct specialist Telegram DM pattern for Son/Faker/Go Youn-jung when cron auto-delivery would make user-facing messages appear from Karina/default; includes required `deliver=local`, prompt block, toolset, and verification checklist.

## Verification Checklist

- `references/karina-slack-team-orchestration-session.md` — concrete setup pattern for a Karina-led Slack team channel with independent specialist profiles, SOUL.md team rules, per-agent daily Markdown work logs, and Slack Socket Mode recovery.

## Verification Checklist

- [ ] Profiles, wrappers, credentials, and models verified per role.
- [ ] Routing rules and ownership boundaries documented.
- [ ] Shared Slack channel rules are present in every relevant `SOUL.md`.
- [ ] Per-profile `.env` files exist for independent bot credentials and do not reuse another profile's tokens.
- [ ] Slack team-wide wake behavior, if enabled, is tested with broadcast-token mention-gating coverage.
- [ ] Every affected profile gateway is restarted and reconnected after SOUL/env/code changes.
- [ ] Daily work-log schema and per-agent folders exist.
- [ ] Daily log cron jobs skip no-work days and deliver locally only.
- [ ] Kanban cards include acceptance criteria and evidence requirements.
- [ ] Worker outputs independently verified before marking work complete.
