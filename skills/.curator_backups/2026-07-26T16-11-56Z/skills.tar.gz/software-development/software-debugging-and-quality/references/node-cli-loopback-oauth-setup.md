# Node CLI setup with loopback OAuth

Use this reference when installing or connecting a Node/npm CLI that authenticates via browser OAuth and a `localhost` callback, especially when Hermes runs on a remote/container host while the user opens the auth URL on their own machine.

## Proven pattern

1. Check package metadata before installing:
   - `npm view <package> version description bin --json`
2. If global install to `/usr/local` fails with permissions, prefer a user-owned npm prefix instead of sudo:
   - `npm config set prefix /opt/data/.npm-global`
   - `export PATH="/opt/data/.npm-global/bin:$PATH"`
   - `npm install -g <package>`
3. Verify installed commands and help:
   - `<cmd> --help`
   - `<cmd> version` or `<cmd> --version`
4. For browser OAuth CLIs, start login in a tracked background process with a fixed port:
   - `export PATH="/opt/data/.npm-global/bin:$PATH"`
   - `<cmd> auth login --port 8765`
5. Send the user the printed authorization URL.
6. If the user’s browser cannot reach `localhost:<port>` after approval, ask them to copy the full callback URL from the browser address bar, usually:
   - `http://localhost:8765/callback?code=...&state=...`
7. From the Hermes host, complete the callback locally:
   - `curl -sS '<full_callback_url>'`
8. Wait/poll the background process and look for a success line such as `Successfully authenticated.`
9. Verify real connectivity with a non-sensitive read-only command, e.g. list models/account/workspaces. Do not print access tokens.

## Higgsfield CLI notes from this pattern

- Package: `@higgsfield/cli`
- Binaries: `higgsfield`, `higgs`, and alias `hf`
- Auth command: `higgsfield auth login --port 8765`
- Auth status can be indirectly verified by a read-only command such as `higgsfield model list --image --json`.
- `higgsfield auth token` prints credentials; avoid using or exposing it unless explicitly required and safe.

## Pitfalls

- Do not treat the user-side `localhost` connection failure as auth failure. In remote/container Hermes, it is expected; the callback URL can often be replayed from the Hermes host.
- Do not pipe untrusted CLI/web output directly into an interpreter for parsing. Save to a temp file first, then parse the file.
- Do not store OAuth tokens in memory or work logs.
