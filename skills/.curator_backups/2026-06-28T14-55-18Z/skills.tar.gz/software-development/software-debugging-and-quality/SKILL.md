---
name: software-debugging-and-quality
description: "Use when diagnosing software defects, validating implementation plans, debugging Python/Node processes, running TDD, requesting review, or simplifying recent code changes."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [debugging, tdd, code-review, refactoring, quality, python, node]
    related_skills: []
---

# Software Debugging and Quality

## Overview

This umbrella covers the class-level loop for understanding, testing, fixing, reviewing, and simplifying code. Use it to avoid the common failure mode of patching symptoms before proving the root cause.

## When to Use

- A bug, failing test, regression, or flaky behavior needs diagnosis.
- You need debugger-level inspection in Python or Node.js.
- The user asks for TDD, a spike, a code review, or cleanup of recent changes.
- A change should be verified before commit/PR.

## Core Loop

1. **Understand before editing**: reproduce the symptom and identify the responsible path.
2. **Make the failure executable**: add or run the smallest test/probe that captures the issue.
3. **Change the minimum code**: fix the root cause, not adjacent symptoms.
4. **Verify broadly enough**: run the targeted test plus relevant adjacent tests/linters.
5. **Review and simplify**: inspect the diff for security, maintainability, and unnecessary complexity.

## Systematic Debugging

- Use the four-phase pattern: root-cause investigation, pattern analysis, hypothesis/testing, implementation.
- Collect evidence from logs, stack traces, tests, source reading, and runtime probes.
- Do not edit until you can explain why the current behavior happens.

## Test-Driven Development

- Enforce RED → GREEN → REFACTOR when adding behavior or fixing a bug.
- RED: write or identify a failing test that proves the desired behavior.
- GREEN: implement the smallest fix.
- REFACTOR: simplify while keeping tests green.
- If you changed production code before a failing test existed, stop and add the test before continuing.

## Spikes

- Use throwaway experiments to validate uncertain libraries, APIs, performance assumptions, or architecture choices.
- Time-box the spike and produce a verdict: VALIDATED, PARTIAL, or INVALIDATED.
- Do not merge spike code directly; translate learnings into production-quality code.

## Python Debugging

- Use `pdb` for local breakpoints, post-mortem debugging, and quick pytest inspection.
- Use `debugpy` when a running process needs DAP/remote attach behavior.
- Prefer no-source-edit launch modes for quick probes; remove any temporary breakpoints before finalizing.

## Node.js Debugging

- Use `node inspect` or `--inspect` with the Chrome DevTools Protocol for Node processes.
- Attach to running processes when restarting would hide the bug.
- For performance/memory issues, capture heap snapshots or CPU profiles rather than guessing.

## Code Review and Simplification

- Before handoff, get the diff, run static/security checks, run relevant tests, self-review, and if useful ask an independent reviewer subagent.
- For cleanup, consider parallel review perspectives: complexity, correctness, and deletion/simplification opportunities.
- Keep only fixes that are supported by failing tests, clear evidence, or measurable simplification.

## Common Pitfalls

1. **Skipping reproduction.** You cannot verify a fix for a bug you never reproduced.
2. **Debugger leftovers.** Remove breakpoints, debug ports, print spam, and temporary probes.
3. **Overfitting tests.** A test that mirrors the implementation does not protect behavior.
4. **Review without running code.** A textual review is not a substitute for execution.

## Verification Checklist

- [ ] Failure or need reproduced/confirmed.
- [ ] Root cause explained in concrete code paths.
- [ ] Test/probe added or selected before changing behavior where practical.
- [ ] Targeted and adjacent verification commands run.
- [ ] Diff reviewed for security, complexity, and accidental artifacts.
