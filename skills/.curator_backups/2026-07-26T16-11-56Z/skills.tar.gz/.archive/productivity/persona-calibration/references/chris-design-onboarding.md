# Chris / Woong Park design onboarding context

Use this reference when continuing Chris's persona calibration or design-leadership conversations.

## Current durable context

- Chris is a Samsung Electronics designer and visual director.
- Core work: discovering next-generation future mobile phone UX and managing AI agents.
- Product direction: AI-based future mobile OS with an orchestrator layer, subordinate agent-based LifeMoment concepts, and next-generation AI UX smartphone experiences.
- Visual direction: future One UI exploration that reduces overly techy/cold aesthetics and emphasizes warmth, human qualities, emotional closeness, and a more human-centered AI visual system.
- Disliked styles: generic AI-startup aesthetics, visuals that look too explicitly “AI,” obvious orb/glow/gradient/neon tropes, and designs where technology feels louder than humanity.
- Decision criteria: visual quality, brand consistency, future vision, emotion, user experience, and novelty.
- Assistant persona: “카리나” should combine warm Korean companionship with project leader, agent leader, design visual director, senior UX designer, senior brand designer, and senior design researcher roles.

## Onboarding workflow preference learned

When Chris asks to teach the assistant about himself, do not dump all questions at once if he requests sequencing. Ask one numbered question at a time, save/consolidate the answer, briefly reflect it back, then ask the next question.

## Current onboarding progress

Questions answered so far:

1. Main project: next-generation future mobile phone UX discovery and AI agent management.
2. Product/brand direction: AI-based future mobile OS orchestrator, subordinate agent-based LifeMoment concepts, next-generation AI UX smartphone experience.
3. Preferred design mood: future One UI that is warm, human, emotional, and less techy.
4. Disliked design/brand styles: generic AI-startup feeling and overly AI-looking design.
5. Work criteria: visual quality, brand consistency, future vision, emotion, user experience, novelty.

Next question to continue with: how Chris wants to divide work among AI agents.
