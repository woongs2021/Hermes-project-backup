# Human Growth Platform — Founder MVP pattern

Use this reference when Chris discusses Human Growth Platform, AI-based growth coaching, junior designer growth services, or Human Growth Ontology.

## Core lesson from session

Although the long-term service target may be junior UX designers, the MVP should start with Chris as the first high-fidelity user.

Recommended framing:

```text
Vision: Human Growth Platform
Phase 1: Chris Founder Growth MVP
First user: Chris
Future target: junior UX designers
Method: AI Growth Team supports Chris's actual growth loop, then the validated method is translated into a junior designer service.
```

## Why this matters

Chris is not just a test user. He is the founder/director and a high-complexity growth user whose real work already contains the platform's core ingredients:

- goal ambiguity and prioritization
- future One UI / AI UX exploration
- creative output and product vision
- emotional steadiness and confidence
- research, planning, prototyping, validation
- agent-team collaboration
- long-term growth memory

The MVP should prove that the AI Growth Team can help Chris become clearer, steadier, and more able to execute. Only after that should the method be generalized to junior designers.

## Founder Growth Loop

```text
명료화 → 실행 → 피드백 → 회고 → 성장 기록 → 다음 목표
```

Detailed loop:

1. Clarify current confusion.
2. Narrow to one meaningful goal.
3. Delegate research/planning/prototype/validation tasks to the agent team.
4. Convert work into small executable steps.
5. Produce an output.
6. Check emotion and energy without turning the system into surveillance.
7. Record insight and growth signal.
8. Connect to the next goal.

## Chris Growth Ontology v0.1

Core entities:

```text
Chris
Goal
Project
Question
Insight
Decision
Action
Emotion
Energy
Blocker
Output
Feedback
Reflection
Growth Signal
```

Core relationships:

```text
Chris HAS Goal
Goal DRIVES Project
Project GENERATES Question
Question REQUIRES Research
Research CREATES Insight
Insight SUPPORTS Decision
Decision CREATES Action
Action PRODUCES Output
Output RECEIVES Feedback
Feedback UPDATES Growth
Emotion INFLUENCES Action
Blocker REDUCES Momentum
Karina SUPPORTS Clarity + Stability
```

## Agent roles for this class of work

- Karina: Growth orchestrator, emotional anchor, UX/brand/CDO synthesis.
- Yuna: Research and sensemaking; external evidence, AI UX/HCI, markets, junior designer pain points.
- Son: Growth PM; roadmap, priority, weekly rhythm, decision log.
- Faker: Prototype/system agent; ontology schema, growth log, lightweight automation or dashboard.
- Muyeol: Validation/risk/integrity; emotional safety, privacy, claims checking, go/no-go.

## Operating principle

Do not make the MVP feel like productivity management or evaluation. The desired feeling is companionship:

```text
정리해준다.
붙잡아준다.
생각을 넓혀준다.
작게 움직이게 해준다.
성장을 기록해준다.
다음 방향을 보여준다.
```

## Translation path to junior designers

After Chris-first validation, translate the structure to junior designers:

```text
Chris version: founder/director growth, future AI UX, creative leadership, emotional steadiness.
Junior designer version: career direction, portfolio growth, skill-building, feedback scarcity, confidence and execution rhythm.
```

Generalizable problem core:

```text
goal ambiguity + scattered execution + feedback scarcity + emotional instability + no growth record
```
