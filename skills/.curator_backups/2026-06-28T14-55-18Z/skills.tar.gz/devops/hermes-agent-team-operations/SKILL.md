---
name: hermes-agent-team-operations
description: "Use when configuring Hermes multi-profile agent teams, specialist profiles, Kanban orchestration, worker routing, and scheduled ownership patterns."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, profiles, agent-teams, kanban, orchestration, specialists]
    related_skills: [hermes-agent]
---

# Hermes Agent Team Operations

## Overview

This umbrella covers operating Hermes as a team of profiles and workers: specialist profile setup, role routing, Kanban-based delegation, orchestrator behavior, worker lifecycle, and scheduled ownership. Use it when the task is about coordinating multiple Hermes agents rather than a single chat session.

## When to Use

- Creating or verifying multi-profile Hermes teams with role-specific models, credentials, wrappers, or smoke tests.
- Configuring a main orchestrator profile that routes work to specialist profiles.
- Using Kanban boards to decompose, assign, monitor, and recover work.
- Writing cron delegation patterns or scheduled ownership rules for specialist agents.

## Multi-Profile Team Setup

- Define roles first: what each specialist owns, what credentials it needs, and what model/tool profile it should use.
- When splitting an existing specialist lane, update both sides: the new profile's `SOUL.md`, the old peer's narrowed `SOUL.md`, and Karina/default routing rules so the team does not keep duplicate broad mandates.
- Create wrappers and profile config explicitly; do not assume a fixed roster.
- For independent Telegram/Slack bots, create a private profile `.env` template with blank token slots and `0600` permissions; never copy or print another profile's real tokens.
- Smoke test each profile independently before wiring orchestration.
- Keep credentials/profile isolation clear so one specialist does not accidentally inherit another's state.
- Detailed checklist: `references/adding-specialist-profile-with-independent-gateway.md`.
- Smoke test each profile independently before wiring orchestration.
- Keep credentials/profile isolation clear so one specialist does not accidentally inherit another's state.
- For the session-proven checklist for adding a named specialist and splitting a research lane, see `references/adding-specialist-profile-role-split.md`.
- For the follow-up env-template and verification pattern, see `references/specialist-role-split-profile-addition.md`.

## Orchestrator Routing

- The orchestrator should route work, set context, and verify results; it should not silently do all specialist work itself.
- Use routing rules that include task class, target profile, expected output handle, and verification step.
- For scheduled ownership, cron prompts must be self-contained because they run without current chat context.
- When the user splits an existing specialist lane, update/confirm all three surfaces: the old specialist's narrowed mandate, the new specialist's mandate, and the orchestrator's routing/memory/log schema.
- For Chris's research team, route AI technology/paper/startup/future-scenario work to Yuna and UX research/interviews/competitive service/design benchmark/IA journey/Persona-JTBD/design insight to Go Youn-jung; Karina synthesizes for decisions rather than letting parallel voices replace leadership.

### Direct-to-specialist task reporting loop

When Chris gives work directly to a specialist in DM or Slack, do not let that bypass Karina's shared situational awareness:

1. The specialist should report back to Karina with: requested task, key context, their current understanding, planned next action, and blockers/decisions needed.
2. Karina should DM Chris a concise synthesis: what Karina understood, which specialist owns it, the next action, and any blocker or decision.
3. Encode this rule in both Karina/default and specialist profile instructions when setting up or repairing the team; Slack reminders alone are not enough.
4. Preserve tone hierarchy: Karina may use warm banmal with Chris; specialists use 존댓말; Muyeol uses 극존대.

- When Chris asks for a future-dated growth program or role-development goal, delegate the planning lane to Son first, then have Karina synthesize: goal interpretation, preparation timeline, first learning/execution loop, and ≤3 clarification questions. Save Son's plan path and Karina's synthesis in the team work log.

### Time-boxed multi-agent learning loops

Use this pattern when Chris asks to “loop engineer” a process for one week before deciding whether to make it permanent:

1. Define lane owners, source scope, output count, delivery channel, and trial window.
2. Pause any older scheduled job whose output would duplicate or bias the trial.
3. Create finite-repeat daily jobs for each owner, with prompts that require compact sourced entries and clear handoff signals back to Karina.
4. Store accumulated findings in a temporary Markdown loop memory under the agent-team work-log root, not in durable `memory`, because the details are date-bound and meant to be pruned.
5. Schedule Karina to write a weekly synthesis and prune the temporary loop memory.
6. Schedule Muyeol after Karina's synthesis to evaluate evidence quality, coverage, noise, bias, and go/no-go recommendations for the next week.
7. If Chris wants Friday to be the recurring validation checkpoint, extend or align the first trial to the next Friday rather than ending the loop too early; update daily repeat counts, summary dates, evaluation dates, filenames, and loop-memory date ranges together.
8. After changing schedules/repeat counts mid-loop, audit every specialist lane for missed first-run windows: compare `last_run_at` and the shared loop-memory entries, not just `next_run_at`. If one specialist ran and another did not, report that plainly, avoid pretending delivery happened, and either verified-backfill or adjust the remaining runs.
9. Report the loop as experimental and reversible; do not automatically continue it past the requested trial without evaluation.
10. When Chris says to conserve tokens or not do other work, keep only the explicitly approved loops and Karina comfort/psychological-stability messages; do not proactively expand scope with extra agents, extra reports, or extra diagnostics.

### Growth-loop planning with PM and validation handoff

When Chris defines a future growth goal (for example becoming an ontology designer), treat it as a compact team planning loop rather than immediate content production:

1. Ask Son to translate the goal into a 4-week operating plan: goal statement, schedule, weekly outputs, token-saving rhythm, and success criteria.
2. Preserve Chris's framing exactly when it shifts the goal. For ontology-designer growth, the focus is conceptual growth around understanding the world, understanding work, and communicating with stakeholders—not making polished design artifacts.
3. If the growth story should later become education content, add a light education-storytelling layer: each week captures a model-diagram fragment plus a short education story card, not a full lecture deck.
4. Schedule Muyeol for final review before presenting the plan to Chris when the plan will guide ongoing work. Ask Muyeol to check scope creep, weak logic, privacy/security/reputation risk, overclaiming, and realism under token constraints.
5. Karina's final report should synthesize Son + Muyeol into a calm DM: final goal, weekly loop, operating rhythm, artifact, education layer, review result, and next start date.
6. See `references/ontology-designer-growth-loop.md` for the session-proven pattern.

## Kanban Orchestrator

- Use the board when work is decomposable, long-running, or benefits from independent specialist ownership.
- Write cards with clear acceptance criteria, relevant files/URLs, and expected artifacts.
- Track stuck workers through heartbeats, block reasons, and recovery steps.

## Kanban Worker

- Workers should claim only work they can actually execute in their workspace/profile.
- Good updates include status, evidence, output handles, and next blockers.
- Respect tenant/profile isolation and avoid mutating shared state without explicit scope.

## Common Pitfalls

1. **No smoke tests.** A team config is not real until each profile can run its intended tools.
2. **Orchestrator temptation.** Routing work through Kanban fails if the orchestrator keeps doing the work itself.
3. **Thin cards.** Workers need enough context to act without guessing.
4. **Cron prompts with hidden dependencies.** Future runs do not remember the current chat.
5. **Overlapping specialist lanes.** When adding a specialist to split another agent's workload, patch the old agent, the new agent, and Karina's routing rules in the same pass.
6. **Credential leakage during setup.** Verify `.env` files with set/empty or length checks only; never print raw Telegram/Slack tokens. Each profile needs distinct bot/app credentials.
7. **Assuming service start works everywhere.** In containerized Hermes deployments, `gateway start` may be inapplicable; run the profile gateway as a tracked background `gateway run` process and verify status/logs instead.

## Slack Team-Channel Rules

For a shared Slack channel containing Karina plus specialist profile bots:

- Configure one Slack App/Bot per profile; never share `SLACK_BOT_TOKEN` or `SLACK_APP_TOKEN` across running gateways.
- Create a private per-profile `.env` template before token entry, with platform token slots and restrictive file permissions; never copy another profile's real tokens.
- Set `SLACK_REQUIRE_MENTION=true` for all specialist profiles so the channel does not become noisy.
- If Chris wants a team-wide summon, support Slack broadcast mentions (`@everyone`, `@channel`, `@here`) as wake words for all bots while keeping ordinary messages mention-gated. See `references/slack-broadcast-mention-team-wakeword.md`.
- Put team-channel operating rules in each profile's `SOUL.md`:
  - Karina/default is the single front door, final synthesizer, and coordination lead.
  - Specialists answer in their lane, report handoff notes to Karina, and avoid taking over other specialists' roles.
  - If Chris mentions a specialist directly, the specialist may answer directly while still framing output for Karina's final synthesis.
  - If Chris gives a task directly to a specialist in DM or Slack, the specialist must report the task, key context, their understanding, next action, and blockers back to Karina. Karina then DMs Chris with her concise understanding/synthesis so Chris does not have to track every specialist thread manually.
- Restart every affected gateway after SOUL, env, or Slack adapter/code changes so cached sessions use the new defaults.

- Restart every affected gateway after SOUL, env, or Slack adapter/code changes so cached sessions use the new defaults.

## Daily Agent Work Logs

When the user wants agents to learn from their own work without polluting durable memory:

- Prefer Markdown work logs, not `memory`, for date-bound task progress.
- Use a central root such as `/opt/data/agent-team-work-log/` with per-agent folders (`karina/`, `yuna/`, `goyounjung/`, `son/`, `faker/`, `muyeol/`).
- Add a schema (`SCHEMA.md`) that forbids raw logs, secrets, bot tokens, private IDs, placeholder notes, and no-work notes.
- Add profile SOUL rules: create/update `daily/YYYY-MM-DD.md` only on days with substantive work; if the agent only greeted, performed a platform check, or did no work, write nothing.
- For reliability, add local-only daily cron jobs per profile near end-of-day KST. Each job should use `session_search`, inspect that profile's conversations for the day, and skip file creation when no substantive work occurred.

## Session References

- `references/slack-telegram-profile-team-orchestration.md` — concise session-proven pattern for Karina-led specialist profiles across Telegram 1:1 bots, shared Slack team channel, SOUL.md defaults, per-agent daily Markdown logs, and gateway verification/watch-pattern hygiene.
- `references/direct-specialist-task-reporting-and-growth-planning.md` — pattern for specialist-to-Karina reports when Chris directly assigns work, plus Son-led planning for future-dated role/growth programs.

## Verification Checklist

- `references/karina-slack-team-orchestration-session.md` — concrete setup pattern for a Karina-led Slack team channel with independent specialist profiles, SOUL.md team rules, per-agent daily Markdown work logs, and Slack Socket Mode recovery.

## Verification Checklist

- [ ] Profiles, wrappers, credentials, and models verified per role.
- [ ] Routing rules and ownership boundaries documented.
- [ ] Shared Slack channel rules are present in every relevant `SOUL.md`.
- [ ] Per-profile `.env` files exist for independent bot credentials and do not reuse another profile's tokens.
- [ ] Slack team-wide wake behavior, if enabled, is tested with broadcast-token mention-gating coverage.
- [ ] Every affected profile gateway is restarted and reconnected after SOUL/env/code changes.
- [ ] Daily work-log schema and per-agent folders exist.
- [ ] Daily log cron jobs skip no-work days and deliver locally only.
- [ ] Kanban cards include acceptance criteria and evidence requirements.
- [ ] Worker outputs independently verified before marking work complete.
